import { Router } from "express";
import type { IRouter } from "express";
import { db, techniciansTable, complaintsTable } from "@workspace/db";
import { eq, desc, ne, and, or } from "drizzle-orm";
import { sql } from "drizzle-orm";
import {
  CreateTechnicianBody,
  UpdateTechnicianBody,
  UpdateTechnicianParams,
  GetTechnicianParams,
  GetTechnicianMapParams,
} from "@workspace/api-zod";
import { hashPassword } from "../lib/auth";

const router: IRouter = Router();

function serializeTechnician(tech: typeof techniciansTable.$inferSelect) {
  return {
    id: tech.id,
    username: tech.username,
    name: tech.name,
    phone: tech.phone,
    area: tech.area,
    isActive: tech.isActive,
    createdAt: tech.createdAt.toISOString(),
  };
}

function serializeComplaint(c: typeof complaintsTable.$inferSelect) {
  return {
    ...c,
    technicianName: null,
    pendingTechnicianIds: [] as number[],
    scheduledDate: c.scheduledDate ?? null,
    completedAt: c.completedAt ? c.completedAt.toISOString() : null,
    createdAt: c.createdAt.toISOString(),
    updatedAt: c.updatedAt.toISOString(),
  };
}

router.get("/technicians", async (_req, res): Promise<void> => {
  const techs = await db.select().from(techniciansTable).orderBy(techniciansTable.name);
  res.json(techs.map(serializeTechnician));
});

router.post("/technicians", async (req, res): Promise<void> => {
  const parsed = CreateTechnicianBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const passwordHash = hashPassword(parsed.data.password);
  const [tech] = await db.insert(techniciansTable).values({
    username: parsed.data.username,
    passwordHash,
    name: parsed.data.name,
    phone: parsed.data.phone,
    area: parsed.data.area,
  }).returning();

  res.status(201).json(serializeTechnician(tech));
});

router.get("/technicians/:id", async (req, res): Promise<void> => {
  const params = GetTechnicianParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [tech] = await db.select().from(techniciansTable)
    .where(eq(techniciansTable.id, params.data.id));

  if (!tech) {
    res.status(404).json({ error: "Technician not found" });
    return;
  }

  const assigned = await db.select().from(complaintsTable)
    .where(eq(complaintsTable.technicianId, tech.id))
    .orderBy(desc(complaintsTable.createdAt));

  res.json({
    ...serializeTechnician(tech),
    assignedComplaints: assigned.map(c => ({
      ...serializeComplaint(c),
      technicianName: tech.name,
    })),
  });
});

router.patch("/technicians/:id", async (req, res): Promise<void> => {
  const params = UpdateTechnicianParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateTechnicianBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const updates: Partial<typeof techniciansTable.$inferInsert> = {};
  if (parsed.data.name != null) updates.name = parsed.data.name;
  if (parsed.data.phone != null) updates.phone = parsed.data.phone;
  if (parsed.data.area != null) updates.area = parsed.data.area;
  if (parsed.data.isActive != null) updates.isActive = parsed.data.isActive;
  if (parsed.data.password) updates.passwordHash = hashPassword(parsed.data.password);

  const [tech] = await db.update(techniciansTable)
    .set(updates)
    .where(eq(techniciansTable.id, params.data.id))
    .returning();

  if (!tech) {
    res.status(404).json({ error: "Technician not found" });
    return;
  }

  res.json(serializeTechnician(tech));
});

router.delete("/technicians/:id", async (req, res): Promise<void> => {
  const params = GetTechnicianParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  await db.update(complaintsTable)
    .set({ technicianId: null })
    .where(eq(complaintsTable.technicianId, params.data.id));

  const [deleted] = await db.delete(techniciansTable)
    .where(eq(techniciansTable.id, params.data.id))
    .returning({ id: techniciansTable.id });

  if (!deleted) {
    res.status(404).json({ error: "Technician not found" });
    return;
  }

  res.status(204).end();
});

router.get("/technicians/:id/map", async (req, res): Promise<void> => {
  const params = GetTechnicianMapParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const techId = params.data.id;

  // Direct assignments
  const assigned = await db.select().from(complaintsTable)
    .where(eq(complaintsTable.technicianId, techId))
    .orderBy(desc(complaintsTable.createdAt));

  // Pending assignments (first-to-accept) — unassigned complaints with this tech in pendingTechnicianIds
  const pendingRaw = await db.select().from(complaintsTable)
    .where(
      and(
        sql`${complaintsTable.pendingTechnicianIds}::jsonb @> ${JSON.stringify([techId])}::jsonb`,
        sql`${complaintsTable.status} NOT IN ('resolved', 'closed')`,
        sql`${complaintsTable.technicianId} IS NULL`,
      )
    )
    .orderBy(desc(complaintsTable.createdAt));

  // Merge, avoiding duplicates (direct takes priority)
  const assignedIds = new Set(assigned.map(c => c.id));
  const pending = pendingRaw.filter(c => !assignedIds.has(c.id));

  function toPin(c: typeof complaintsTable.$inferSelect, isPending: boolean) {
    return {
      complaintId: c.id,
      ticketId: c.ticketId,
      customerName: c.customerName,
      customerPhone: c.customerPhone,
      placeName: c.placeName,
      address: c.address,
      lat: c.lat ?? null,
      lng: c.lng ?? null,
      locationSource: c.locationSource ?? null,
      urgency: c.urgency,
      urgencyColor: c.urgencyColor ?? "#6b7280",
      status: c.status,
      complaintType: c.complaintType,
      description: c.description,
      scheduledDate: c.scheduledDate ?? null,
      adminNotes: c.adminNotes ?? null,
      isPending,
      createdAt: c.createdAt.toISOString(),
    };
  }

  const pins = [
    ...assigned.map(c => toPin(c, false)),
    ...pending.map(c => toPin(c, true)),
  ];

  res.json(pins);
});

export default router;
