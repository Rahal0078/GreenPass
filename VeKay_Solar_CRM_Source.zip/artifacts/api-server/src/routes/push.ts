import { Router } from "express";
import type { IRouter } from "express";
import { db, pushSubscriptionsTable, techniciansTable } from "@workspace/db";
import { eq, inArray } from "drizzle-orm";
import { logger } from "../lib/logger";

const router: IRouter = Router();

const VAPID_PUBLIC_KEY = process.env.VAPID_PUBLIC_KEY ?? "BC0q5FFcmmCWrbpnOB5mrLIUpqVSD3fwZ7e1Z5VvsuSj2jEOVydX2ZTOWdsYV9LW4PiJf6xilxSU6kCJtpKMzmw";
const VAPID_PRIVATE_KEY = process.env.VAPID_PRIVATE_KEY ?? "fBJsdw-Bq6KwuNa8-sTSgt251WQMwntnnTyQS5ZMR2s";
const VAPID_EMAIL = "mailto:info.vekay@gmail.com";

async function getWebPush() {
  const webpush = await import("web-push");
  webpush.default.setVapidDetails(VAPID_EMAIL, VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY);
  return webpush.default;
}

router.get("/push/vapid-key", (_req, res): void => {
  res.json({ publicKey: VAPID_PUBLIC_KEY });
});

router.post("/push/subscribe", async (req, res): Promise<void> => {
  const session = req.session as any;
  if (!session?.userId || session.role !== "technician") {
    res.status(401).json({ error: "Not authenticated" });
    return;
  }

  const { endpoint, p256dh, auth } = req.body;
  if (!endpoint || !p256dh || !auth) {
    res.status(400).json({ error: "Missing subscription fields" });
    return;
  }

  try {
    await db.insert(pushSubscriptionsTable).values({
      technicianId: session.userId,
      endpoint,
      p256dh,
      auth,
    }).onConflictDoUpdate({
      target: pushSubscriptionsTable.endpoint,
      set: { p256dh, auth, technicianId: session.user.id },
    });

    res.json({ message: "Subscribed" });
  } catch (err) {
    logger.warn({ err }, "Push subscribe error");
    res.status(500).json({ error: "Failed to save subscription" });
  }
});

router.post("/push/unsubscribe", async (req, res): Promise<void> => {
  const { endpoint } = req.body;
  if (!endpoint) {
    res.status(400).json({ error: "Missing endpoint" });
    return;
  }

  await db.delete(pushSubscriptionsTable)
    .where(eq(pushSubscriptionsTable.endpoint, endpoint));

  res.json({ message: "Unsubscribed" });
});

export async function sendPushToTechnicians(technicianIds: number[], payload: { title: string; body: string; data?: Record<string, unknown> }) {
  if (!technicianIds.length) return;

  let webpush: Awaited<ReturnType<typeof getWebPush>>;
  try {
    webpush = await getWebPush();
  } catch (err) {
    logger.warn({ err }, "web-push init failed");
    return;
  }

  const subs = await db.select().from(pushSubscriptionsTable)
    .where(inArray(pushSubscriptionsTable.technicianId, technicianIds));

  const notification = JSON.stringify({
    title: payload.title,
    body: payload.body,
    data: payload.data ?? {},
    icon: "/greenpass-logo.jpeg",
    badge: "/favicon.svg",
  });

  for (const sub of subs) {
    try {
      await webpush.sendNotification(
        { endpoint: sub.endpoint, keys: { p256dh: sub.p256dh, auth: sub.auth } },
        notification,
      );
    } catch (err: any) {
      if (err.statusCode === 410 || err.statusCode === 404) {
        await db.delete(pushSubscriptionsTable).where(eq(pushSubscriptionsTable.endpoint, sub.endpoint));
      } else {
        logger.warn({ err, technicianId: sub.technicianId }, "Push send failed");
      }
    }
  }
}

export default router;
