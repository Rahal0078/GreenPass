import { Router } from "express";
import type { IRouter } from "express";
import { db, complaintsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { sql } from "drizzle-orm";
import { syncToSheets } from "../lib/sheets";

const router: IRouter = Router();

router.get("/customers", async (_req, res): Promise<void> => {
  const rows = await db
    .select({
      phone: complaintsTable.customerPhone,
      name: complaintsTable.customerName,
      email: complaintsTable.customerEmail,
      totalComplaints: sql<number>`count(*)::int`,
      openComplaints: sql<number>`count(*) filter (where ${complaintsTable.status} in ('open','in_progress'))::int`,
      resolvedComplaints: sql<number>`count(*) filter (where ${complaintsTable.status} in ('resolved','closed'))::int`,
      firstSeen: sql<string>`min(${complaintsTable.createdAt})::text`,
      lastSeen: sql<string>`max(${complaintsTable.createdAt})::text`,
    })
    .from(complaintsTable)
    .groupBy(complaintsTable.customerPhone, complaintsTable.customerName, complaintsTable.customerEmail)
    .orderBy(sql`max(${complaintsTable.createdAt}) desc`);

  res.json(rows);
});

router.get("/customers/:phone", async (req, res): Promise<void> => {
  const phone = req.params.phone;
  if (!phone) {
    res.status(400).json({ error: "Phone required" });
    return;
  }

  const complaints = await db
    .select()
    .from(complaintsTable)
    .where(eq(complaintsTable.customerPhone, phone))
    .orderBy(desc(complaintsTable.createdAt));

  if (complaints.length === 0) {
    res.status(404).json({ error: "Customer not found" });
    return;
  }

  const customer = {
    phone: complaints[0].customerPhone,
    name: complaints[0].customerName,
    email: complaints[0].customerEmail,
    totalComplaints: complaints.length,
    complaints: complaints.map((c) => ({
      ...c,
      completedAt: c.completedAt ? c.completedAt.toISOString() : null,
      createdAt: c.createdAt.toISOString(),
      updatedAt: c.updatedAt.toISOString(),
    })),
  };

  res.json(customer);
});

router.patch("/customers/:phone", async (req, res): Promise<void> => {
  const phone = req.params.phone;
  if (!phone) {
    res.status(400).json({ error: "Phone required" });
    return;
  }

  const { name, email } = req.body as { name?: string; email?: string };
  if (!name && !email) {
    res.status(400).json({ error: "Provide at least name or email to update" });
    return;
  }

  const updates: Record<string, string> = {};
  if (name) updates.customerName = name;
  if (email) updates.customerEmail = email;

  const updated = await db.update(complaintsTable)
    .set(updates)
    .where(eq(complaintsTable.customerPhone, phone))
    .returning({ id: complaintsTable.id });

  if (updated.length === 0) {
    res.status(404).json({ error: "Customer not found" });
    return;
  }

  res.json({ updated: updated.length });
  syncToSheets().catch(() => {});
});

router.delete("/customers/:phone", async (req, res): Promise<void> => {
  const phone = req.params.phone;
  if (!phone) {
    res.status(400).json({ error: "Phone required" });
    return;
  }

  const deleted = await db.delete(complaintsTable)
    .where(eq(complaintsTable.customerPhone, phone))
    .returning({ id: complaintsTable.id });

  if (deleted.length === 0) {
    res.status(404).json({ error: "Customer not found" });
    return;
  }

  res.status(204).end();
  syncToSheets().catch(() => {});
});

export default router;
