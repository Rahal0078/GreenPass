import { Router } from "express";
import type { IRouter } from "express";
import { db, adminsTable, techniciansTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { AdminLoginBody, TechnicianLoginBody } from "@workspace/api-zod";
import { verifyPassword } from "../lib/auth";
import { saveExcelBackup } from "./reports";

const router: IRouter = Router();

router.post("/auth/admin/login", async (req, res): Promise<void> => {
  const parsed = AdminLoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { username, password } = parsed.data;
  const [admin] = await db.select().from(adminsTable).where(eq(adminsTable.username, username));

  if (!admin || !verifyPassword(password, admin.passwordHash)) {
    res.status(401).json({ error: "Invalid username or password" });
    return;
  }

  req.session.userId = admin.id;
  req.session.role = "admin";
  req.session.name = admin.name;
  req.session.username = admin.username;

  // Refresh Excel backup on every admin login (non-blocking)
  saveExcelBackup().catch(() => {});

  res.json({ id: admin.id, username: admin.username, name: admin.name, role: "admin" });
});

router.post("/auth/technician/login", async (req, res): Promise<void> => {
  const parsed = TechnicianLoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { username, password } = parsed.data;
  const [tech] = await db.select().from(techniciansTable).where(eq(techniciansTable.username, username));

  if (!tech || !verifyPassword(password, tech.passwordHash)) {
    res.status(401).json({ error: "Invalid username or password" });
    return;
  }

  if (!tech.isActive) {
    res.status(401).json({ error: "Account is inactive. Contact admin." });
    return;
  }

  req.session.userId = tech.id;
  req.session.role = "technician";
  req.session.name = tech.name;
  req.session.username = tech.username;

  res.json({ id: tech.id, username: tech.username, name: tech.name, role: "technician" });
});

router.post("/auth/login", async (req, res): Promise<void> => {
  const { username, password } = req.body ?? {};
  if (!username || !password) {
    res.status(400).json({ error: "Username and password are required" });
    return;
  }

  // Try admin first
  const [admin] = await db.select().from(adminsTable).where(eq(adminsTable.username, username));
  if (admin && verifyPassword(password, admin.passwordHash)) {
    req.session.userId = admin.id;
    req.session.role = "admin";
    req.session.name = admin.name;
    req.session.username = admin.username;
    saveExcelBackup().catch(() => {});
    res.json({ id: admin.id, username: admin.username, name: admin.name, role: "admin" });
    return;
  }

  // Try technician
  const [tech] = await db.select().from(techniciansTable).where(eq(techniciansTable.username, username));
  if (tech && verifyPassword(password, tech.passwordHash)) {
    if (!tech.isActive) {
      res.status(401).json({ error: "Account is inactive. Contact admin." });
      return;
    }
    req.session.userId = tech.id;
    req.session.role = "technician";
    req.session.name = tech.name;
    req.session.username = tech.username;
    res.json({ id: tech.id, username: tech.username, name: tech.name, role: "technician" });
    return;
  }

  res.status(401).json({ error: "Invalid username or password" });
});

router.post("/auth/logout", (req, res): void => {
  req.session.destroy(() => {
    res.json({ message: "Logged out successfully" });
  });
});

router.get("/auth/me", (req, res): void => {
  if (!req.session.userId) {
    res.status(401).json({ error: "Not authenticated" });
    return;
  }
  res.json({
    id: req.session.userId,
    username: req.session.username,
    name: req.session.name,
    role: req.session.role,
  });
});

export default router;
