import { Router } from "express";
import type { IRouter } from "express";
import { db, complaintsTable, techniciansTable } from "@workspace/db";
import { eq, desc, gte, count, sql } from "drizzle-orm";

const router: IRouter = Router();

router.get("/dashboard/summary", async (_req, res): Promise<void> => {
  const all = await db.select().from(complaintsTable);
  const techs = await db.select().from(techniciansTable);

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const summary = {
    totalComplaints: all.length,
    openComplaints: all.filter(c => c.status === "open").length,
    inProgress: all.filter(c => c.status === "in_progress").length,
    resolved: all.filter(c => c.status === "resolved").length,
    closed: all.filter(c => c.status === "closed").length,
    critical: all.filter(c => c.urgency === "critical").length,
    highUrgency: all.filter(c => c.urgency === "high").length,
    totalTechnicians: techs.length,
    activeTechnicians: techs.filter(t => t.isActive).length,
    todayComplaints: all.filter(c => c.createdAt >= today).length,
  };

  res.json(summary);
});

router.get("/dashboard/activity", async (req, res): Promise<void> => {
  const limitRaw = req.query.limit;
  const limit = typeof limitRaw === "string" ? Math.min(parseInt(limitRaw, 10) || 20, 50) : 20;

  const complaints = await db.select().from(complaintsTable)
    .orderBy(desc(complaintsTable.updatedAt))
    .limit(limit);

  const activity = complaints.map(c => ({
    id: c.id,
    ticketId: c.ticketId,
    customerName: c.customerName,
    placeName: c.placeName,
    urgency: c.urgency,
    urgencyColor: c.urgencyColor,
    action: c.status === "resolved" ? "resolved" : c.status === "in_progress" ? "in_progress" : "registered",
    createdAt: c.updatedAt.toISOString(),
  }));

  res.json(activity);
});

router.get("/dashboard/urgency-breakdown", async (_req, res): Promise<void> => {
  const all = await db.select().from(complaintsTable);
  const urgencyMap: Record<string, { urgency: string; urgencyColor: string; count: number }> = {
    low: { urgency: "low", urgencyColor: "#3b82f6", count: 0 },
    medium: { urgency: "medium", urgencyColor: "#f97316", count: 0 },
    high: { urgency: "high", urgencyColor: "#dc2626", count: 0 },
    critical: { urgency: "critical", urgencyColor: "#7f1d1d", count: 0 },
  };

  for (const c of all) {
    if (urgencyMap[c.urgency]) urgencyMap[c.urgency].count++;
  }

  res.json(Object.values(urgencyMap));
});

router.get("/dashboard/technician-workload", async (_req, res): Promise<void> => {
  const techs = await db.select().from(techniciansTable);
  const complaints = await db.select().from(complaintsTable);

  const workload = techs.map(t => {
    const assigned = complaints.filter(c => c.technicianId === t.id);
    return {
      technicianId: t.id,
      technicianName: t.name,
      area: t.area,
      total: assigned.length,
      open: assigned.filter(c => c.status === "open").length,
      inProgress: assigned.filter(c => c.status === "in_progress").length,
      resolved: assigned.filter(c => c.status === "resolved").length,
    };
  });

  res.json(workload);
});

export default router;
