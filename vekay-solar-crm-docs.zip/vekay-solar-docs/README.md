# VeKay Solar CRM — Complete Documentation Package

**Version:** 1.0 | **Date:** June 2026 | **Company:** GreenPass Technologies / VeKay Solar

---

## What's in This Package

| File / Folder | Contents |
|---|---|
| `docs/01-architecture.md` | System architecture, tech stack, data flow |
| `docs/02-setup-guide.md` | Full installation & environment setup |
| `docs/03-database-schema.md` | All tables, columns, types, and relationships |
| `docs/04-api-reference.md` | Every API endpoint with request/response shapes |
| `docs/05-design-system.md` | UI design, color palette, components, layouts |
| `docs/06-user-guide.md` | Step-by-step guide for every portal and feature |
| `docs/07-demonstration.md` | End-to-end demo walkthrough of all major flows |
| `docs/08-email-system.md` | All automated emails, templates, and triggers |
| `docs/09-integrations.md` | Google Sheets, Google Drive, Push Notifications |
| `docs/10-deployment.md` | Production deployment checklist |
| `screenshots/` | Live screenshots of the running application |

---

## System at a Glance

VeKay Solar CRM is a **full-stack complaint and solar installation management system** built for VeKay Solar, a solar panel installation company operating across Kerala, India. It is developed and operated by **GreenPass Technologies**.

### Three Portals

| Portal | URL | Who Uses It |
|---|---|---|
| **Public Portal** | `/` | Customers — file complaints, track tickets |
| **Admin Portal** | `/admin` | Office staff — manage complaints, projects, staff |
| **Technician Portal** | `/tech` | Field technicians — view map, complete jobs |

### Key Capabilities

- Customer complaint registration with GPS location capture
- Ticket tracking by ticket ID
- Admin dashboard with live charts and statistics  
- Complaint management: urgency levels, technician assignment, status updates
- Solar installation project tracking with 12-stage workflow
- Quotation upload/approval via coordinator and client
- Project closure request/approval workflow
- Technician field map (OpenStreetMap, urgency-coloured pins)
- Automated customer emails at every status change
- Daily Excel report generation and email delivery
- Google Sheets sync for project data
- Google Drive integration for quotation PDFs
- Web Push notifications for technicians
- Kerala-specific 50-location dataset with GPS coordinates

---

## Default Login Credentials

| Role | Username | Password |
|---|---|---|
| Admin | `admin` | `admin123` |
| Technician | `rajesh_k` | `tech123` |
| Technician | `suresh_m` | `tech456` |
| Technician | `anoop_v` | `tech789` |
| Coordinator | `meera_coord` | `coord123` |
