# Integrations

---

## Google Sheets

### Purpose
Automatically sync complaint and project data to a Google Sheet for reporting and offline access.

### Setup
1. Create a Google Sheet with two sheets: `Complaints` and `Projects`
2. Share the sheet with your service account email (Editor)
3. Copy the sheet ID from its URL: `https://docs.google.com/spreadsheets/d/SHEET_ID/edit`
4. Set `GOOGLE_SERVICE_ACCOUNT_JSON` environment variable
5. The sheet ID is hardcoded in `artifacts/api-server/src/lib/sheets.ts` — update it to match your sheet

### Complaints Sheet Columns
| Column | Data |
|---|---|
| A | Ticket ID |
| B | Customer Name |
| C | Phone |
| D | Email |
| E | KSEB Consumer No |
| F | Address |
| G | Place Name |
| H | District |
| I | Pincode |
| J | Complaint Type |
| K | Description |
| L | Urgency |
| M | Status |
| N | Technician |
| O | Resolution Notes |
| P | Created At |
| Q | Completed At |

### Projects Sheet Columns
| Column | Data |
|---|---|
| A | Registered At |
| B | FL No |
| C | Customer Name |
| D | Place |
| E | kW |
| F | Phone |
| G | Email |
| H | Consumer No |
| I | Total Amount |
| J | Coordinator |
| K | Quotation Status |
| L | Closure Status |
| M–X | Stage 1–12 (completion timestamps) |

### Sync Triggers
- Complaint completed → row added/updated in Complaints sheet
- Project stage updated → row added/updated in Projects sheet
- Both are upserts: finds existing row by ID, updates it; creates new row if not found

### Code Location
- `artifacts/api-server/src/lib/sheets.ts` — complaints sync
- `artifacts/api-server/src/lib/sheets-projects.ts` — projects sync + `parseStageLog()` helper

---

## Google Drive

### Purpose
Store quotation PDF files in Google Drive so coordinators and clients can access them via email link.

### Setup
Same service account as Google Sheets (must have Drive API enabled and folder access).

The target folder ID is configured in `artifacts/api-server/src/lib/drive.ts`.

### Workflow
1. Admin uploads PDF via `POST /api/quotation/:id/upload`
2. Server receives file via multer (saved to `uploads/` locally)
3. File is uploaded to Google Drive via Drive API
4. Google Drive File ID is stored in `projects.quotationFileId`
5. Download URL embedded in coordinator approval email

### File Naming
`quotation_{projectId}_{timestamp}.pdf`

Example: `quotation_42_1780750659220.pdf`

### Code Location
`artifacts/api-server/src/lib/drive.ts`

---

## Web Push Notifications

### Purpose
Send real-time push notifications to technicians' browsers when new jobs are assigned.

### Setup

Generate VAPID keys (one-time):
```bash
npx web-push generate-vapid-keys
```

Set environment variables:
```env
VAPID_PUBLIC_KEY=your-public-key
VAPID_PRIVATE_KEY=your-private-key
```

If not set, fallback hardcoded keys are used (development only — not secure for production).

### Browser Registration Flow
1. Technician logs in → field map loads
2. Frontend calls `POST /api/push/subscribe` with the browser's push subscription object
3. Server stores subscription data in the session (or a dedicated subscriptions table)
4. Admin assigns a complaint → server sends push via `web-push.sendNotification()`

### Push Payload Format
```json
{
  "title": "New Job Assigned",
  "body": "VKS-XXXXXXXXXX — High urgency complaint in Kochi",
  "icon": "/favicon.svg"
}
```

### Code Location
- `artifacts/api-server/src/routes/push.ts`
- `artifacts/vekay-solar/src/pages/tech/Map.tsx` (subscription registration)
- `artifacts/vekay-solar/public/sw.js` (service worker — handles push events)

---

## Gmail SMTP (nodemailer)

### Purpose
Send all automated customer notification emails and daily reports.

### Configuration
```env
GMAIL_APP_PASSWORD=xxxx-xxxx-xxxx-xxxx
```

**Note:** This must be a Gmail **App Password**, not your regular Gmail password.

Generate at: Google Account → Security → 2-Step Verification → App passwords

### SMTP Settings (internal)
```javascript
{
  service: 'gmail',
  auth: {
    user: 'info.vekay@gmail.com',
    pass: process.env.GMAIL_APP_PASSWORD
  }
}
```

### Behaviour
- If `GMAIL_APP_PASSWORD` is not set: all email calls are silently skipped, a `warn` log is written
- If SMTP connection fails: error is logged, request continues (emails are non-blocking)
- All HTML is inline-styled for email client compatibility

---

## Kerala Places Data

### Purpose
Provide a curated list of 50 Kerala locations with GPS coordinates for the complaint form's place auto-fill.

### Data Format
```typescript
interface Place {
  name: string;       // Town/village name
  district: string;   // Kerala district name
  pincode: string;    // 6-digit postal code
  lat: number;        // GPS latitude
  lng: number;        // GPS longitude
}
```

### Coverage
50 locations across all 14 Kerala districts:
- Thiruvananthapuram district: Thiruvananthapuram, Nedumangad, Neyyattinkara, Varkala, Attingal
- Kollam district: Kollam, Punalur, Karunagappally, Paravur
- Pathanamthitta district: Pathanamthitta, Adoor, Tiruvalla, Ranni
- Alappuzha district: Alappuzha, Chengannur, Kayamkulam, Mavelikkara
- Kottayam district: Kottayam, Changanacherry, Pala, Ettumanoor, Vaikom
- Idukki district: Thodupuzha, Munnar, Kattappana
- Ernakulam district: Ernakulam/Kochi, Aluva, Angamaly, Perumbavoor, Muvattupuzha, Kothamangalam
- Thrissur district: Thrissur, Chalakudy, Kodungallur, Irinjalakuda
- Palakkad district: Palakkad, Ottappalam, Shornur, Mannarkkad
- Malappuram district: Malappuram, Tirur, Manjeri, Perinthalmanna
- Kozhikode district: Kozhikode, Vatakara, Koyilandy, Ramanattukara
- Wayanad district: Kalpetta, Mananthavady, Sulthan Bathery
- Kannur district: Kannur, Thalassery, Iritty, Payyanur
- Kasaragod district: Kasaragod, Kanhangad, Bekal

### How It's Used
When the customer clicks "Get My Location":
1. Browser captures GPS coordinates (latitude, longitude)
2. Frontend sends coordinates to backend OR matches client-side
3. The nearest place in the 50-location dataset is selected (Haversine distance)
4. Place name, district, and pincode are auto-filled in the form

### Code Location
`artifacts/api-server/src/lib/places.ts` — returns all 50 locations via `GET /api/places`
