# API Reference

**Base URL:** `/api`  
**Authentication:** Session cookie (`sid`) — required for all endpoints except auth, public complaints, track, places, and quotation/closure token links.  
**Content-Type:** `application/json` (except file upload endpoints)

---

## Health

### GET `/api/healthz`
Returns server status.

**Response:**
```json
{ "status": "ok", "ts": "2026-06-06T10:00:00.000Z" }
```

---

## Authentication

### POST `/api/auth/login`
Login for admins, technicians, and coordinators. All use the same endpoint.

**Request:**
```json
{ "username": "admin", "password": "admin123" }
```

**Response (admin):**
```json
{
  "user": { "id": 1, "username": "admin", "name": "Administrator", "email": "admin@vekaysolar.in" },
  "role": "admin"
}
```

**Response (technician):**
```json
{
  "user": { "id": 2, "username": "rajesh_k", "name": "Rajesh Kumar", "phone": "+91 9876543210", "roles": ["technician"] },
  "role": "technician"
}
```

**Errors:** `401 { error: "Invalid credentials" }`

---

### GET `/api/auth/me`
Returns current session user. Returns `401` if not logged in.

### POST `/api/auth/logout`
Destroys session. Returns `200 { message: "Logged out" }`.

---

## Places (Kerala Locations)

### GET `/api/places`
Returns all 50 Kerala locations with coordinates.

**Response:**
```json
[
  { "name": "Thiruvananthapuram", "district": "Thiruvananthapuram", "pincode": "695001", "lat": 8.5241, "lng": 76.9366 },
  { "name": "Kochi", "district": "Ernakulam", "pincode": "682001", "lat": 9.9312, "lng": 76.2673 },
  ...
]
```

---

## Complaints

### POST `/api/complaints`
Submit a new complaint (public — no auth required).

**Request:**
```json
{
  "customerName": "Ajith Kumar",
  "customerPhone": "+91 9876543210",
  "customerEmail": "ajith@example.com",
  "consumerNo": "1234567890123",
  "address": "TC 10/1234, Gandhi Road",
  "placeName": "Thiruvananthapuram",
  "district": "Thiruvananthapuram",
  "pincode": "695001",
  "lat": 8.5241,
  "lng": 76.9366,
  "complaintType": "Panel Not Generating",
  "description": "Solar panel output dropped to near zero",
  "scheduledDate": "2026-06-10"
}
```

**Response:**
```json
{
  "message": "Complaint registered",
  "ticketId": "VKS-A1B2C3D4E5",
  "id": 42
}
```
Triggers: Registration email to customer.

---

### GET `/api/complaints`
List all complaints. **Auth required (admin).**

**Query params:** `status`, `urgency`, `technicianId`, `search`, `page`, `limit`

**Response:**
```json
{
  "complaints": [...],
  "total": 150,
  "page": 1,
  "limit": 50
}
```

---

### GET `/api/complaints/:id`
Get a single complaint by ID. **Auth required.**

---

### GET `/api/complaints/track/:ticketId`
Public ticket tracking — no auth required.

**Response:**
```json
{
  "ticketId": "VKS-A1B2C3D4E5",
  "status": "assigned",
  "urgency": "high",
  "customerName": "Ajith Kumar",
  "complaintType": "Panel Not Generating",
  "placeName": "Thiruvananthapuram",
  "technicianName": "Rajesh Kumar",
  "createdAt": "2026-06-06T10:00:00.000Z"
}
```

---

### PATCH `/api/complaints/:id`
Update complaint fields (urgency, assigned technician, status). **Auth required (admin).**

**Request (assign technician + set urgency):**
```json
{
  "urgency": "high",
  "technicianId": 2
}
```
Triggers: Assignment email to customer.

---

### PATCH `/api/complaints/:id/status`
Update complaint status (technician action). **Auth required (technician).**

**Request:**
```json
{
  "status": "going"
}
```

Valid transitions: `going` → `reached` → `completed`

For `completed`, also include:
```json
{
  "status": "completed",
  "resolutionNotes": "Replaced faulty micro-inverter. System restored to full output."
}
```
Triggers: Status-change email to customer.

---

### DELETE `/api/complaints/:id`
Delete a complaint. **Auth required (admin).**

---

## Technicians

### GET `/api/technicians`
List all staff (technicians + coordinators). **Auth required.**

**Response:**
```json
[
  {
    "id": 2,
    "username": "rajesh_k",
    "name": "Rajesh Kumar",
    "phone": "+91 9876543210",
    "email": "rajesh@vekaysolar.in",
    "specialization": "Solar Panel Installation",
    "experience": "5 years",
    "roles": ["technician"]
  }
]
```

---

### POST `/api/technicians`
Create new technician or coordinator. **Auth required (admin).**

**Request:**
```json
{
  "username": "new_tech",
  "password": "password123",
  "name": "New Technician",
  "phone": "+91 9999999999",
  "email": "new@vekaysolar.in",
  "specialization": "Inverter Maintenance",
  "experience": "2 years",
  "roles": ["technician"]
}
```

---

### PATCH `/api/technicians/:id`
Update technician details. **Auth required (admin).**

---

### DELETE `/api/technicians/:id`
Delete technician. **Auth required (admin).**

---

## Projects

### GET `/api/projects`
List all projects. **Auth required.**

**Response:**
```json
[
  {
    "id": 1,
    "flNo": "FL-001",
    "customerName": "Arun Kumar",
    "place": "Kochi",
    "kw": "5",
    "phone": "+91 9876543210",
    "coordinator": "Meera Nair",
    "quotation": "CLIENT_APPROVED",
    "stages": ["done","done","","","","","","","","","",""],
    "closureStatus": "PENDING",
    "activityLog": [...],
    "createdAt": "2026-06-01T..."
  }
]
```

---

### POST `/api/projects`
Create new project. **Auth required (admin).**

**Request:**
```json
{
  "customerName": "Arun Kumar",
  "flNo": "FL-002",
  "place": "Thrissur",
  "kw": "3",
  "phone": "+91 9876543211",
  "email": "arun@example.com",
  "consumerNo": "9876543210123",
  "totalAmount": "150000",
  "gmapLink": "https://maps.google.com/?q=...",
  "coordinator": "Meera Nair",
  "registeredAt": "2026-06-06"
}
```

---

### PATCH `/api/projects/:id`
Update project fields, stages, or remarks. **Auth required (admin).**

**Request (update stages with custom date):**
```json
{
  "stages": ["done","done","done","","","","","","","","",""],
  "stageDate": "2026-05-15",
  "stageRemarks": ["","","Survey done by Rajesh","","","","","","","","",""]
}
```

**Request (update basic fields):**
```json
{
  "coordinator": "Meera Nair",
  "totalAmount": "175000",
  "remark": "Customer requested premium panels"
}
```

---

### DELETE `/api/projects/:id`
Delete project. **Auth required (admin).**

---

## Quotation Workflow

### POST `/api/quotation/:id/upload`
Upload quotation PDF for a project. **Auth required (admin).**

**Request:** `multipart/form-data` with field `file` (PDF)

**Response:**
```json
{ "message": "Quotation uploaded and sent for coordinator approval", "fileId": "drive-file-id" }
```
Triggers: Email to coordinator with approval/rejection links.

---

### GET `/api/quotation/coordinator-approve/:token`
Coordinator approval link (from email). **No auth required (token-based).**

Transitions quotation: `SENT` → `COORDINATOR_APPROVED`  
Triggers: Email to client with approval link.

---

### GET `/api/quotation/coordinator-reject/:token`
Coordinator rejection link (from email). **No auth required (token-based).**

Transitions quotation: `SENT` → `COORDINATOR_REJECTED`

---

### GET `/api/quotation/client-approve/:token`
Client approval link (from email). **No auth required (token-based).**

Transitions quotation: `COORDINATOR_APPROVED` → `CLIENT_APPROVED`

---

### GET `/api/quotation/:id/file`
Download quotation PDF. **Auth required (admin).**

---

## Closure Workflow

### POST `/api/closure/:id/request`
Admin requests project closure. **Auth required (admin).**

Sends closure approval email to coordinator.

---

### GET `/api/closure/approve/:token`
Coordinator approves closure (from email). **No auth required.**

Transitions: `REQUESTED` → `APPROVED`

---

### GET `/api/closure/reject/:token`
Coordinator rejects closure (from email). **No auth required.**

Transitions: `REQUESTED` → `REJECTED`

---

## Dashboard

### GET `/api/dashboard`
Returns statistics for the admin dashboard. **Auth required (admin).**

**Response:**
```json
{
  "totalComplaints": 150,
  "pending": 20,
  "assigned": 45,
  "going": 10,
  "reached": 8,
  "completed": 67,
  "criticalCount": 5,
  "highCount": 30,
  "mediumCount": 80,
  "lowCount": 35,
  "byDistrict": [
    { "district": "Ernakulam", "count": 45 },
    ...
  ],
  "recentComplaints": [...]
}
```

---

## Reports

### GET `/api/reports/excel`
Download daily complaints Excel report. **Auth required (admin).**

Returns an Excel file stream (`.xlsx`).  
Use `fetch` + blob pattern (not React Query hook) for file download.

---

### POST `/api/reports/email`
Send daily report email to info.vekay@gmail.com. **Auth required (admin).**

Requires `GMAIL_APP_PASSWORD` env var.

---

## Customers

### GET `/api/customers`
List all unique customers from complaints. **Auth required (admin).**

---

## Push Notifications

### POST `/api/push/subscribe`
Register a browser push subscription. **Auth required (technician).**

**Request:**
```json
{
  "subscription": { "endpoint": "...", "keys": { "auth": "...", "p256dh": "..." } }
}
```

---

### POST `/api/push/send`
Send a push notification to a technician. **Auth required (admin).**

**Request:**
```json
{ "technicianId": 2, "title": "New job assigned", "body": "Complaint #VKS-ABC in Kochi" }
```

---

## Media

### GET `/api/media/:filename`
Serve uploaded files (e.g. quotation PDFs). **Auth required.**

---

## Error Responses

All errors follow this format:
```json
{ "error": "Human-readable error message" }
```

| Status | Meaning |
|---|---|
| 400 | Bad request / validation error |
| 401 | Not authenticated |
| 403 | Authenticated but not authorized |
| 404 | Resource not found |
| 409 | Conflict (e.g. duplicate username) |
| 500 | Internal server error |
