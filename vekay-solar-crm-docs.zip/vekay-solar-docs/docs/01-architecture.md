# System Architecture

## Overview

VeKay Solar CRM is built as a **pnpm monorepo** with three workspace packages that talk to a shared PostgreSQL database hosted on Neon (cloud PostgreSQL).

```
┌─────────────────────────────────────────────────────────┐
│                    User's Browser                       │
│  ┌────────────────┐  ┌───────────────┐  ┌───────────┐  │
│  │ Public Portal  │  │ Admin Portal  │  │Tech Portal│  │
│  │  React + Vite  │  │ React + Vite  │  │React+Vite │  │
│  └───────┬────────┘  └──────┬────────┘  └─────┬─────┘  │
└──────────┼──────────────────┼─────────────────┼─────────┘
           │     HTTPS / Proxy (same SPA bundle)│
           ▼                  ▼                 ▼
┌──────────────────────────────────────────────────────────┐
│              Replit Reverse Proxy (port 80)              │
│              Routes /api/* → API Server                  │
│              Routes /* → React SPA (Vite dev server)     │
└──────────────────────────────────────────────────────────┘
           │                  │
           ▼                  ▼
┌─────────────────┐  ┌──────────────────────┐
│   API Server    │  │   Vite Dev Server    │
│  Express 5      │  │   (React SPA)        │
│  Port 8080      │  │   Port 24488         │
│  /api/*         │  │   serves frontend    │
└────────┬────────┘  └──────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────────────────┐
│                   Neon PostgreSQL                        │
│   (cloud serverless PostgreSQL, accessed via            │
│    NEON_DATABASE_URL env variable)                      │
│                                                         │
│  Tables: admins, technicians, complaints, projects,     │
│          session                                        │
└─────────────────────────────────────────────────────────┘
         │
         ├──► Google Sheets API (project data sync)
         ├──► Google Drive API (quotation PDFs)
         └──► Gmail SMTP (automated emails via nodemailer)
```

---

## Technology Stack

### Backend
| Technology | Version | Purpose |
|---|---|---|
| Node.js | 24 | Runtime |
| TypeScript | 5.9 | Type safety |
| Express | 5 | HTTP framework |
| express-session | 1.x | Session-based authentication |
| connect-pg-simple | — | Session storage in PostgreSQL |
| Drizzle ORM | — | Type-safe database queries |
| Zod (v4) | — | Schema validation |
| drizzle-zod | — | Generate Zod schemas from Drizzle tables |
| pino / pino-http | — | Structured JSON logging |
| cors | — | Cross-origin resource sharing |
| cookie-parser | — | Cookie parsing middleware |
| exceljs | — | Excel report generation |
| nodemailer | — | Email delivery via Gmail SMTP |
| multer | — | File upload handling (quotation PDFs) |
| web-push | — | Push notification delivery |
| googleapis | — | Google Sheets + Drive API client |

### Frontend
| Technology | Version | Purpose |
|---|---|---|
| React | 18/19 | UI framework |
| Vite | — | Dev server + build tool |
| TypeScript | 5.9 | Type safety |
| Tailwind CSS | — | Utility-first styling |
| Shadcn/ui | — | Pre-built accessible components |
| wouter | — | Lightweight React routing |
| React Query (TanStack) | — | Server-state, caching, refetch |
| Orval | 8 | OpenAPI → React Query hooks codegen |
| react-leaflet + leaflet | — | Interactive map (OpenStreetMap tiles) |
| Recharts | — | Dashboard charts |

### Infrastructure & Tooling
| Technology | Purpose |
|---|---|
| pnpm workspaces | Monorepo package management |
| esbuild | API server build (CJS bundle) |
| Neon PostgreSQL | Cloud PostgreSQL database |
| Replit | Hosting and deployment |
| Google Service Account | Sheets + Drive authentication |

---

## Workspace Structure

```
workspace/
├── artifacts/
│   ├── api-server/           ← Express API server
│   │   ├── src/
│   │   │   ├── app.ts        ← Express app setup (CORS, session, routes)
│   │   │   ├── index.ts      ← Entry point (port binding)
│   │   │   ├── routes/       ← 14 route files
│   │   │   │   ├── auth.ts
│   │   │   │   ├── complaints.ts
│   │   │   │   ├── projects.ts
│   │   │   │   ├── technicians.ts
│   │   │   │   ├── dashboard.ts
│   │   │   │   ├── reports.ts
│   │   │   │   ├── quotation.ts
│   │   │   │   ├── closure.ts
│   │   │   │   ├── customers.ts
│   │   │   │   ├── push.ts
│   │   │   │   ├── places.ts
│   │   │   │   ├── media.ts
│   │   │   │   └── health.ts
│   │   │   └── lib/
│   │   │       ├── auth.ts          ← requireAuth middleware
│   │   │       ├── email.ts         ← 5 email types + daily report
│   │   │       ├── sheets.ts        ← Google Sheets: complaints sync
│   │   │       ├── sheets-projects.ts ← Google Sheets: projects sync
│   │   │       ├── drive.ts         ← Google Drive: quotation PDF upload
│   │   │       ├── places.ts        ← 50 Kerala locations with lat/lng
│   │   │       ├── logger.ts        ← pino logger singleton
│   │   │       └── utils.ts         ← nowIST(), dateToIST(), addLog()
│   │   └── uploads/          ← Quotation PDFs uploaded by admin
│   │
│   └── vekay-solar/          ← React SPA
│       └── src/
│           ├── App.tsx        ← Router + auth context provider
│           ├── lib/
│           │   └── auth-context.tsx  ← useAuth() hook + session state
│           ├── components/
│           │   ├── layout/
│           │   │   ├── AdminLayout.tsx
│           │   │   ├── TechLayout.tsx
│           │   │   └── PublicLayout.tsx
│           │   └── ui/       ← Shadcn/ui components
│           └── pages/
│               ├── public/
│               │   ├── Home.tsx        ← Complaint registration
│               │   └── TrackTicket.tsx ← Ticket status lookup
│               ├── admin/
│               │   ├── Dashboard.tsx   ← Charts + stats
│               │   ├── Complaints.tsx  ← Complaint management table
│               │   ├── Projects.tsx    ← Solar project tracker
│               │   ├── Technicians.tsx ← Staff management
│               │   └── Reports.tsx     ← Excel report download/email
│               └── tech/
│                   └── Map.tsx         ← Leaflet map + job completion
│
├── lib/
│   ├── api-spec/
│   │   └── openapi.yaml      ← OpenAPI 3.0 spec (source of truth)
│   ├── api-client/           ← Generated Axios client (from Orval)
│   ├── api-client-react/     ← Generated React Query hooks (from Orval)
│   └── db/
│       └── src/
│           └── schema/
│               ├── admins.ts
│               ├── technicians.ts
│               ├── complaints.ts
│               └── projects.ts
└── scripts/                  ← Utility scripts
```

---

## Authentication Flow

```
Browser                    API Server                  Database
  │                            │                           │
  │── POST /api/auth/login ──► │                           │
  │   {username, password}     │── SELECT from admins ───► │
  │                            │   or technicians           │
  │                            │◄── user row ──────────────│
  │                            │                           │
  │                            │── bcrypt.compare()        │
  │                            │                           │
  │                            │── req.session.userId = id │
  │                            │── req.session.role = ...  │
  │                            │── req.session.save() ───► session table
  │                            │                           │
  │◄── 200 {user, role} ───────│                           │
  │    Set-Cookie: sid=...     │                           │
  │                            │                           │
  │── GET /api/complaints ───► │                           │
  │   Cookie: sid=...          │── verify session ───────► session table
  │                            │── requireAuth middleware  │
  │◄── 200 [complaints] ───────│                           │
```

Session cookies are:
- `httpOnly: true` (no JS access)
- `secure: true` in production (HTTPS only)
- `sameSite: none` in production, `lax` in development
- `maxAge: 30 days` (rolling — resets on each request)

---

## Data Flow: Complaint Lifecycle

```
Customer fills form → POST /api/complaints
         │
         ▼
   DB: complaints table
   status = "pending"
   ticketId = "VKS-XXXXXXXXXX"
         │
         ▼
   Email: Complaint Registered (→ customer)
         │
         ▼
Admin sets urgency + assigns technician
   PATCH /api/complaints/:id
   status = "assigned"
         │
         ▼
   Email: Technician Assigned (→ customer)
         │
         ▼
Technician clicks "Going" on map
   PATCH /api/complaints/:id/status
   status = "going"
         │
         ▼
   Email: Technician On the Way (→ customer)
         │
         ▼
Technician clicks "Reached"
   status = "reached"
         │
         ▼
   Email: Technician Arrived (→ customer)
         │
         ▼
Technician fills resolution notes, clicks "Complete"
   status = "completed"
         │
         ▼
   Email: Complaint Resolved (→ customer)
   Google Sheets sync (complaints sheet)
```

---

## Data Flow: Project Lifecycle

```
Admin creates project → POST /api/projects
         │
         ▼
   DB: projects table
   stages = [] (12 empty stages)
   quotation = "PENDING"
   closureStatus = "PENDING"
         │
         ▼
Admin uploads quotation PDF → POST /api/quotation/:id/upload
   File → /uploads/ directory
   File also uploaded to Google Drive
   quotation → "SENT"
   Email: Quotation sent to coordinator for approval
         │
         ▼
Coordinator approves → GET /api/quotation/coordinator-approve/:token
   quotation → "COORDINATOR_APPROVED"
   Email: Client approval link sent
         │
         ▼
Client approves → GET /api/quotation/client-approve/:token
   quotation → "CLIENT_APPROVED"
         │
         ▼
Admin marks 12 stages as complete (with dates)
   PATCH /api/projects/:id (stages array)
   stageLog tracks change history
   Google Sheets sync
         │
         ▼
Admin requests closure → POST /api/closure/:id/request
   closureStatus → "REQUESTED"
   Email: Coordinator closure approval link
         │
         ▼
Coordinator approves closure → GET /api/closure/approve/:token
   closureStatus → "APPROVED"
         │
         ▼
   Project fully closed
```
