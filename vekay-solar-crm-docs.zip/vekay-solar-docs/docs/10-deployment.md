# Deployment Guide

---

## Replit Deployment (Recommended)

VeKay Solar CRM is designed and hosted on **Replit**. The deployment process uses Replit's built-in publishing feature.

### Pre-Deployment Checklist

- [ ] `NEON_DATABASE_URL` set (Neon cloud PostgreSQL)
- [ ] `SESSION_SECRET` set (long random string, minimum 32 characters)
- [ ] `GMAIL_APP_PASSWORD` set (if email features needed)
- [ ] `GOOGLE_SERVICE_ACCOUNT_JSON` set (if Sheets/Drive needed)
- [ ] `VAPID_PUBLIC_KEY` and `VAPID_PRIVATE_KEY` set (if push notifications needed)
- [ ] Database schema pushed: `pnpm --filter @workspace/db run push`
- [ ] Admin user seeded in database
- [ ] All typechecks pass: `pnpm run typecheck`
- [ ] Frontend builds successfully: `pnpm --filter @workspace/vekay-solar run build`

### Deploy on Replit

1. Click **Deploy** in the Replit workspace toolbar.
2. Replit builds the project and assigns a `.replit.app` domain.
3. The production URL is available immediately.

### What Happens in Production

When `NODE_ENV=production`:
- API server serves the built Vite frontend from `artifacts/vekay-solar/dist/public/`
- Session cookies use `secure: true` and `sameSite: none` (required for cross-origin proxy)
- Single server handles both API routes (`/api/*`) and frontend SPA routing

### Production URL Structure

```
https://your-app.replit.app/          → Public complaint form
https://your-app.replit.app/track/:id → Public ticket tracking
https://your-app.replit.app/admin     → Admin/Staff login
https://your-app.replit.app/api/      → API endpoints
```

---

## Manual / VPS Deployment

### Build

```bash
# 1. Build the frontend
pnpm --filter @workspace/vekay-solar run build
# Output: artifacts/vekay-solar/dist/public/

# 2. Build the API server
pnpm --filter @workspace/api-server run build
# Output: artifacts/api-server/dist/index.cjs
```

### Run

```bash
NODE_ENV=production \
NEON_DATABASE_URL=postgresql://... \
SESSION_SECRET=your-secret \
GMAIL_APP_PASSWORD=xxxx-xxxx-xxxx-xxxx \
node artifacts/api-server/dist/index.cjs
```

The server starts on port `8080` by default (override with `PORT` env var).

### Nginx Reverse Proxy (optional)

```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:8080;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

Add SSL with Let's Encrypt: `certbot --nginx -d your-domain.com`

### PM2 Process Manager

```bash
npm install -g pm2
pm2 start artifacts/api-server/dist/index.cjs --name vekay-solar
pm2 save
pm2 startup
```

---

## Environment Variables Reference

| Variable | Required | Default | Description |
|---|---|---|---|
| `NEON_DATABASE_URL` | ✅ Yes | — | Neon PostgreSQL connection string |
| `DATABASE_URL` | Fallback | — | Local PostgreSQL (fallback) |
| `SESSION_SECRET` | ✅ Yes | `greenpass-crm-secret-2024` | Session encryption key |
| `NODE_ENV` | — | `development` | Set to `production` for prod |
| `PORT` | — | `8080` | API server port |
| `GMAIL_APP_PASSWORD` | Optional | — | Gmail App Password for emails |
| `SENDER_EMAIL` | Optional | `info.vekay@gmail.com` | Override sender email |
| `COMPANY_NAME` | Optional | `GreenPass Technologies` | Override company name in emails |
| `COMPANY_TAGLINE` | Optional | `Kerala's Leading Solar...` | Override tagline in emails |
| `GOOGLE_SERVICE_ACCOUNT_JSON` | Optional | — | Full JSON of service account key |
| `VAPID_PUBLIC_KEY` | Optional | hardcoded | Web push VAPID public key |
| `VAPID_PRIVATE_KEY` | Optional | hardcoded | Web push VAPID private key |
| `REPLIT_DOMAINS` | Auto | — | Set by Replit (allowed CORS origins) |

---

## Security Notes for Production

1. **Change default credentials immediately**
   - Admin: `admin` / `admin123` → set a strong password
   - All technician passwords: `tech123`, `tech456`, `tech789` → change all

2. **Use a strong SESSION_SECRET**
   - Minimum 32 characters
   - Random: `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`

3. **Database**
   - Use Neon's connection pooling for high traffic
   - Enable SSL: `?sslmode=require` in connection string

4. **File uploads**
   - Quotation PDFs are stored locally in `/uploads/` — back this up if not using Drive
   - File type validation: only PDFs accepted

5. **Email security**
   - Use Gmail App Passwords, not your account password
   - Consider using a dedicated email account for the CRM

6. **HTTPS**
   - Replit handles SSL automatically
   - For VPS: use Let's Encrypt + Nginx
   - Session cookies require HTTPS in production (`secure: true`)

---

## Monitoring & Logs

### Replit
- Workflow console shows real-time pino JSON logs
- Filter logs by level: `{"level":30}` = info, `{"level":40}` = warn, `{"level":50}` = error

### Log Format
```json
{
  "level": 30,
  "time": 1749200000000,
  "pid": 12345,
  "hostname": "...",
  "req": { "id": 1, "method": "POST", "url": "/api/complaints" },
  "res": { "statusCode": 201 },
  "responseTime": 45
}
```

### Health Check
Monitor via: `GET /api/healthz` → should return `{"status":"ok"}` with 200.

---

## Backup Strategy

1. **Database:** Neon provides automatic daily backups. For additional safety, export with:
   ```bash
   pg_dump $NEON_DATABASE_URL > backup-$(date +%F).sql
   ```

2. **Uploaded files:** The `/uploads/` directory contains quotation PDFs. Back up or preferably use Google Drive (which is already backed up by Google).

3. **Google Sheets:** Auto-synced data is backed up in Google's infrastructure.
