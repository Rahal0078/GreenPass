# System Demonstration — End-to-End Walkthrough

This document walks through the complete lifecycle of both a **customer complaint** and a **solar installation project**, demonstrating every major system feature.

---

## Demo Flow 1: Complaint Lifecycle

### Step 1 — Customer submits a complaint

**URL:** `http://localhost/`  
**Actor:** Customer (no login required)

1. Open the public portal home page.
2. Fill in:
   - Name: `Priya Menon`
   - Phone: `+91 9876543299`
   - Email: `priya.menon@example.com`
   - KSEB Consumer No: `6543210987654`
   - Click **"Get My Location"** → allow browser location → system auto-fills: Place: Kochi, District: Ernakulam, Pincode: 682001
   - Complaint Type: `Inverter Fault`
   - Description: `Inverter shows error code E-03, system not producing power since yesterday`
   - Preferred Date: tomorrow's date
3. Click **Submit Complaint**.

**Result:** 
- Ticket ID displayed: e.g. `VKS-PQ9R8S7T6U`
- Email received by priya.menon@example.com with ticket badge and complaint details.

---

### Step 2 — Admin reviews and assigns

**URL:** `http://localhost/admin` → login as `admin` / `admin123`  
**Actor:** Admin

1. Open **Complaints** page.
2. Find the new complaint (Status: Pending). Click to open detail panel.
3. Set **Urgency** to `High` (orange).
4. Select technician **Rajesh Kumar** from the dropdown.
5. Click **Assign**.

**Result:**
- Status changes to `assigned`.
- Customer receives "Technician Assigned" email with Rajesh Kumar's name and phone number.
- Complaint appears on Rajesh's field map with an orange pin.

---

### Step 3 — Technician marks "Going"

**URL:** `http://localhost/admin` → login as `rajesh_k` / `tech123`  
**Actor:** Technician

1. Field map opens (auto-redirect).
2. Orange pin at Kochi location visible.
3. Click pin → popup shows Priya Menon, Inverter Fault, High urgency.
4. Click **"Going"** button.

**Result:**
- Status changes to `going`.
- Customer receives "Technician On the Way" email.

---

### Step 4 — Technician marks "Reached"

(Still logged in as Rajesh)

1. Click the pin again → popup now shows "Reached" button.
2. Click **"Reached"**.

**Result:**
- Status changes to `reached`.
- Customer receives "Technician Arrived at Your Location" email.

---

### Step 5 — Technician completes the job

1. Click pin → popup shows "Complete" button.
2. Click **Complete** → resolution dialog opens.
3. Enter notes: `Replaced faulty inverter control board. Performed factory reset. System restored to full output (4.8 kW). Recommended customer to avoid power surges.`
4. Confirm.

**Result:**
- Status changes to `completed`.
- Customer receives "Complaint Resolved" email with resolution notes.
- Pin disappears from the map.
- Google Sheets complaint log is updated.

---

### Step 6 — Verify on dashboard

(Logged in as admin)

1. Open **Dashboard**.
2. Total Completed count incremented.
3. District chart shows Ernakulam count increased.
4. Recent complaints shows Priya Menon's ticket as completed.

---

### Step 7 — Generate and email report

1. Open **Reports** page.
2. Click **"Download Excel Report"** → Excel file downloaded with today's complaints.
3. Click **"Email Report"** → daily report email sent to info.vekay@gmail.com.

---

## Demo Flow 2: Solar Installation Project

### Step 1 — Admin creates project

**Actor:** Admin

1. Open **Projects** → click **"+ New Project"**.
2. Fill in:
   - Customer Name: `Biju Thomas`
   - FL No: `FL-2026-042`
   - Place: `Thrissur`
   - kW: `5`
   - Phone: `+91 9745632100`
   - Email: `biju.thomas@example.com`
   - KSEB Consumer No: `7654321098765`
   - Total Amount: `₹2,10,000`
   - Coordinator: `Meera Nair`
   - Registered At: today
3. Click **Create**.

**Result:** Project `FL-2026-042` appears in the list. All 12 stages are blank.

---

### Step 2 — Upload quotation PDF

1. Click the project → open detail panel → go to **Quotation** tab.
2. Click **"Upload Quotation PDF"** → select a PDF file.
3. Click Upload.

**Result:**
- PDF is saved to `/uploads/` directory and uploaded to Google Drive.
- Quotation status: `SENT`.
- Coordinator Meera Nair receives an email with:
  - Project summary (customer, place, kW, amount)
  - PDF download link
  - "Approve Quotation" and "Reject Quotation" buttons.

---

### Step 3 — Coordinator approves quotation

**Actor:** Meera Nair (via email link, no login required)

1. Opens approval email.
2. Clicks **"Approve Quotation"**.
3. Browser shows: "Quotation approved. Client notification sent."

**Result:**
- Quotation status: `COORDINATOR_APPROVED`.
- Biju Thomas receives an email with a **"Approve this Quotation"** link and PDF download link.

---

### Step 4 — Client approves quotation

**Actor:** Biju Thomas (via email link, no login required)

1. Opens client approval email.
2. Clicks **"Approve this Quotation"**.
3. Browser shows: "Thank you! Your quotation has been approved. Our team will begin your installation."

**Result:**
- Quotation status: `CLIENT_APPROVED`.
- Project is ready to proceed to installation.

---

### Step 5 — Admin records stage progress

**Actor:** Admin

1. Open project detail panel → **Stages** tab.
2. Check **"Application Submitted"** and **"Survey Completed"** checkboxes.
3. Both stages ticked — a "Stage Date" panel appears at the bottom.
4. Click **"Save as Today"** to record today's date and time for both.

**Result:**
- Both stages show today's timestamp.
- Stage log updated.
- Google Sheets synced.
- Activity log entry: `"Stages updated"`.

Later, when recording a stage that happened in the past:
1. Tick **"Sanction Approved"**.
2. Click the calendar icon → pick `15 May 2026`.
3. Click **"Save"**.

**Result:**
- Stage log: `"15 May 26, 12:00 PM (recorded 06 Jun 26, 3:40 PM)"`.
- Both the actual completion date and the recording time are preserved.

---

### Step 6 — Complete all stages

Repeat Stage 5 for all 12 stages over the course of the installation project.

---

### Step 7 — Request project closure

1. All stages complete, quotation approved.
2. Click **"Request Closure"** in the panel footer.

**Result:**
- Closure status: `REQUESTED`.
- Coordinator Meera Nair receives a closure approval email with project summary.

---

### Step 8 — Coordinator approves closure

**Actor:** Meera Nair (via email link)

1. Clicks **"Approve Closure"** in the email.

**Result:**
- Closure status: `APPROVED`.
- Project fully closed.
- Activity log updated.

---

## System-Level Demonstrations

### A — Google Sheets Sync

After any stage update or complaint completion:
- Open the connected Google Sheet.
- New row (or updated row) appears within seconds.
- Complaints sheet: ticket ID, customer, status, technician, urgency, timestamps.
- Projects sheet: all 12 stage dates, quotation status, closure status.

### B — Push Notifications

With the technician portal open and push permission granted:
1. Admin assigns a new complaint to Rajesh Kumar.
2. Rajesh's browser shows a push notification: "New Complaint Assigned — VKS-XXX, High urgency in Kochi".

### C — Ticket Tracking (Public)

1. Open `http://localhost/track/VKS-PQ9R8S7T6U`.
2. Enter the ticket ID.
3. Status, urgency, and technician name displayed in real time.

### D — Excel Download

1. Admin → Reports → Download Excel.
2. Excel file contains all complaints for the day in a formatted sheet.
3. Columns: Ticket ID, Customer Name, Phone, Location, District, Complaint Type, Urgency, Status, Technician, Registered On, Completed On.

---

## Demo Credentials Summary

| Portal | Username | Password | Access |
|---|---|---|---|
| Admin | `admin` | `admin123` | Full admin access |
| Technician | `rajesh_k` | `tech123` | Field map + job completion |
| Technician | `suresh_m` | `tech456` | Field map + job completion |
| Technician | `anoop_v` | `tech789` | Field map + job completion |
| Coordinator | `meera_coord` | `coord123` | Can view projects (approvals via email) |
