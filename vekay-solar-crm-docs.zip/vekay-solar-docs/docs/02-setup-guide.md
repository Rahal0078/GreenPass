# Backend Setup Guide

## Prerequisites

| Requirement | Version | Notes |
|---|---|---|
| Node.js | 24+ | Use nvm or Replit's managed runtime |
| pnpm | 9+ | `npm install -g pnpm` |
| PostgreSQL | 15+ | Local or Neon (cloud) |
| Git | any | |

---

## Step 1: Clone & Install

```bash
git clone <your-repo-url>
cd workspace

# Install all dependencies for all packages
pnpm install
```

---

## Step 2: Environment Variables

Create a `.env` file at the project root **or** set these as secrets in your hosting environment.

### Required

```env
# PostgreSQL connection string (Neon cloud recommended)
NEON_DATABASE_URL=postgresql://user:password@host/dbname?sslmode=require

# Falls back to this if NEON_DATABASE_URL is not set
DATABASE_URL=postgresql://user:password@localhost:5432/vekay_solar

# Session encryption secret (use a long random string)
SESSION_SECRET=your-very-long-random-secret-here-minimum-32-chars
```

### Optional — Email Reports

```env
# Gmail App Password for nodemailer
# Generate at: Google Account → Security → 2-Step Verification → App passwords
GMAIL_APP_PASSWORD=xxxx-xxxx-xxxx-xxxx

# Override sender email (default: info.vekay@gmail.com)
SENDER_EMAIL=info.vekay@gmail.com

# Override company name in emails (default: GreenPass Technologies)
COMPANY_NAME=GreenPass Technologies
COMPANY_TAGLINE=Kerala's Leading Solar Project Expert
```

### Optional — Google Sheets & Drive

```env
# Full JSON content of your Google Service Account key file
# The account needs Editor access on your target Google Sheet
# and access to the Google Drive folder for quotation PDFs
GOOGLE_SERVICE_ACCOUNT_JSON={"type":"service_account","project_id":"...","private_key":"..."}
```

### Optional — Web Push Notifications

```env
# Generate with: npx web-push generate-vapid-keys
VAPID_PUBLIC_KEY=your-vapid-public-key
VAPID_PRIVATE_KEY=your-vapid-private-key
```

---

## Step 3: Database Setup

### Option A — Push schema to Neon/PostgreSQL (recommended for dev)

```bash
pnpm --filter @workspace/db run push
```

This runs `drizzle-kit push` which creates or updates all tables to match the schema.

### Option B — Manual SQL

Run the following SQL on your PostgreSQL instance:

```sql
-- Admins table
CREATE TABLE IF NOT EXISTS admins (
  id SERIAL PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Technicians table (also stores coordinators via roles JSON)
CREATE TABLE IF NOT EXISTS technicians (
  id SERIAL PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  name TEXT NOT NULL,
  phone TEXT NOT NULL DEFAULT '',
  email TEXT NOT NULL DEFAULT '',
  specialization TEXT NOT NULL DEFAULT '',
  experience TEXT NOT NULL DEFAULT '',
  roles TEXT NOT NULL DEFAULT '["technician"]',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Complaints table
CREATE TABLE IF NOT EXISTS complaints (
  id SERIAL PRIMARY KEY,
  ticket_id TEXT NOT NULL UNIQUE,
  customer_name TEXT NOT NULL,
  customer_phone TEXT NOT NULL DEFAULT '',
  customer_email TEXT NOT NULL DEFAULT '',
  consumer_no TEXT NOT NULL DEFAULT '',
  address TEXT NOT NULL,
  place_name TEXT NOT NULL,
  district TEXT NOT NULL DEFAULT '',
  pincode TEXT NOT NULL DEFAULT '',
  lat NUMERIC,
  lng NUMERIC,
  complaint_type TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  scheduled_date TEXT,
  urgency TEXT NOT NULL DEFAULT 'medium',
  status TEXT NOT NULL DEFAULT 'pending',
  technician_id INTEGER,
  pending_technician_ids TEXT NOT NULL DEFAULT '[]',
  resolution_notes TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Projects table
CREATE TABLE IF NOT EXISTS projects (
  id SERIAL PRIMARY KEY,
  registered_at TEXT NOT NULL DEFAULT '',
  fl_no TEXT NOT NULL DEFAULT '',
  customer_name TEXT NOT NULL,
  place TEXT NOT NULL DEFAULT '',
  kw TEXT NOT NULL DEFAULT '',
  phone TEXT NOT NULL DEFAULT '',
  email TEXT NOT NULL DEFAULT '',
  consumer_no TEXT NOT NULL DEFAULT '',
  total_amount TEXT NOT NULL DEFAULT '',
  gmap_link TEXT NOT NULL DEFAULT '',
  coordinator TEXT NOT NULL DEFAULT '',
  quotation TEXT NOT NULL DEFAULT 'PENDING',
  quotation_file_id TEXT DEFAULT '',
  quotation_token TEXT DEFAULT '',
  quotation_client_token TEXT DEFAULT '',
  stages TEXT NOT NULL DEFAULT '[]',
  stage_remarks TEXT NOT NULL DEFAULT '[]',
  stage_log TEXT NOT NULL DEFAULT '[]',
  remark TEXT NOT NULL DEFAULT '',
  activity_log TEXT NOT NULL DEFAULT '[]',
  closure_status TEXT NOT NULL DEFAULT 'PENDING',
  closure_token TEXT DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Session table (auto-created by connect-pg-simple)
CREATE TABLE IF NOT EXISTS session (
  sid TEXT NOT NULL PRIMARY KEY,
  sess JSONB NOT NULL,
  expire TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_session_expire ON session(expire);
```

### Seed Default Admin

```sql
-- Password hash for 'admin123' (bcrypt, 10 rounds)
INSERT INTO admins (username, password_hash, name, email)
VALUES (
  'admin',
  '$2b$10$YourBcryptHashHere',   -- generate with: node -e "require('bcrypt').hash('admin123',10).then(console.log)"
  'Administrator',
  'admin@vekaysolar.in'
)
ON CONFLICT (username) DO NOTHING;
```

### Seed Default Technicians

```sql
INSERT INTO technicians (username, password_hash, name, phone, specialization, experience, roles)
VALUES
  ('rajesh_k', '$2b$10$...', 'Rajesh Kumar',  '+91 9876543210', 'Solar Panel Installation', '5 years', '["technician"]'),
  ('suresh_m', '$2b$10$...', 'Suresh Menon',  '+91 9876543211', 'Electrical Systems',       '3 years', '["technician"]'),
  ('anoop_v',  '$2b$10$...', 'Anoop Varma',   '+91 9876543212', 'Inverter Maintenance',     '4 years', '["technician"]'),
  ('meera_coord', '$2b$10$...', 'Meera Nair', '',               '',                         '',        '["coordinator"]')
ON CONFLICT (username) DO NOTHING;
```

---

## Step 4: Google Service Account Setup (Optional)

Required for Google Sheets sync and Drive quotation uploads.

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a project → Enable APIs: **Google Sheets API**, **Google Drive API**
3. IAM & Admin → Service Accounts → Create Service Account
4. Keys → Add Key → JSON → Download
5. Paste the full JSON content as `GOOGLE_SERVICE_ACCOUNT_JSON` env var
6. Share your Google Sheet with the service account email (Editor access)
7. Share your Google Drive folder with the service account email (Editor access)

---

## Step 5: Running the Application

### Development (Replit)

Replit automatically runs both workflows:

```
Workflow 1: pnpm --filter @workspace/api-server run dev
Workflow 2: pnpm --filter @workspace/vekay-solar run dev
```

### Development (Local)

Open two terminal windows:

```bash
# Terminal 1 — API server (hot-reload with tsx)
pnpm --filter @workspace/api-server run dev

# Terminal 2 — Frontend (Vite dev server with HMR)
pnpm --filter @workspace/vekay-solar run dev
```

Visit:
- Frontend: http://localhost:24488
- API: http://localhost:8080/api/healthz

### Production Build

```bash
# Build API server (esbuild → dist/index.cjs)
pnpm --filter @workspace/api-server run build

# Build frontend (Vite → dist/public/)
pnpm --filter @workspace/vekay-solar run build

# Run production server
NODE_ENV=production node artifacts/api-server/dist/index.cjs
```

In production, the API server also serves the built frontend SPA from `artifacts/vekay-solar/dist/public/`.

---

## Step 6: After Schema Changes

If you modify any file in `lib/db/src/schema/`:

```bash
# Push changes to DB
pnpm --filter @workspace/db run push

# Rebuild lib declarations
pnpm run typecheck:libs
```

If you modify `lib/api-spec/openapi.yaml`:

```bash
# Regenerate React Query hooks and Zod schemas
pnpm --filter @workspace/api-spec run codegen
```

---

## Healthcheck

```bash
curl http://localhost:80/api/healthz
# → {"status":"ok","ts":"..."}
```

---

## Common Issues

| Problem | Solution |
|---|---|
| `Cannot find module '@workspace/db'` | Run `pnpm run typecheck:libs` to rebuild lib declarations |
| Session not persisting | Check `SESSION_SECRET` is set and `sameSite` cookie matches environment |
| CORS errors in browser | Add your domain to `REPLIT_DOMAINS` env var |
| Google Sheets not syncing | Check `GOOGLE_SERVICE_ACCOUNT_JSON` is valid JSON and sheet is shared |
| Emails not sending | Verify `GMAIL_APP_PASSWORD` is set (not regular Gmail password) |
| Push notifications not delivered | Check VAPID keys are set; subscription must be re-registered after key change |
