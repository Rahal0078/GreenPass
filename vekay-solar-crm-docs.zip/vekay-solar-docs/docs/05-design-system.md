# Design System

## Brand Identity

**Company:** GreenPass Technologies / VeKay Solar  
**Tagline:** Kerala's Leading Solar Project Expert  
**Brand theme:** Clean, professional, green — representing solar energy and environmental trust.

---

## Color Palette

### Primary Brand Colors

| Name | Hex | Usage |
|---|---|---|
| Brand Green (Dark) | `#1a5c38` | Primary buttons, headers, accents, links |
| Brand Green (Medium) | `#16a34a` | Success states, active indicators |
| Brand Light Green | `#f0fdf4` | Backgrounds, highlight cards |
| Green Border | `#bbf7d0` | Card borders, input focus rings |

### Urgency Colors (Complaints)

| Urgency | Color | Hex |
|---|---|---|
| Critical | Red | `#dc2626` / `#991b1b` |
| High | Orange | `#ea580c` / `#f97316` |
| Medium | Amber | `#d97706` / `#f59e0b` |
| Low | Blue/Green | `#3b82f6` / `#16a34a` |

### Status Colors (Complaint Status)

| Status | Color |
|---|---|
| Pending | Gray |
| Assigned | Blue |
| Going | Orange |
| Reached | Purple |
| Completed | Green |

### Semantic Colors

| Purpose | Color | Hex |
|---|---|---|
| Info/Alert | Blue | `#eff6ff` / `#3b82f6` |
| Warning | Amber | `#fffbeb` / `#f59e0b` |
| Danger | Red | `#fef2f2` / `#dc2626` |
| Success | Green | `#f0fdf4` / `#16a34a` |

---

## Typography

**Font family:** `'Segoe UI', Arial, sans-serif` (system font stack)  
**Email font:** Same stack for maximum email client compatibility.

| Element | Size | Weight |
|---|---|---|
| Page titles | `text-2xl` (24px) | 700 |
| Section headings | `text-lg` (18px) | 600 |
| Card headings | `text-base` (16px) | 600 |
| Body text | `text-sm` (14px) | 400 |
| Small / labels | `text-xs` (12px) | 400–500 |

---

## Component Library

Built on **Shadcn/ui** (Radix UI primitives + Tailwind CSS).

### Core Components Used

| Component | Usage |
|---|---|
| `Button` | Primary (`bg-green-700`), Secondary, Ghost, Destructive variants |
| `Card` | Dashboard stats, complaint cards, project info panels |
| `Badge` | Urgency indicators, status pills |
| `Dialog` | Confirmation dialogs, stage date picker |
| `Sheet` | Right-side panel for project details |
| `Select` | Urgency picker, technician assignment dropdowns |
| `Input` | All form fields |
| `Textarea` | Description, resolution notes |
| `Table` | Complaints list, projects list, technician list |
| `Calendar` | Stage date selection (custom date picker) |
| `Tabs` | Dashboard sections |
| `Skeleton` | Loading states |
| `Sonner` | Toast notifications |
| `AlertDialog` | Destructive action confirmation |

---

## Layout System

### Page Layouts

**PublicLayout** — minimal top nav with logo, "New Complaint", "Track Ticket", "Staff Login"  
**AdminLayout** — sidebar navigation with sections: Dashboard, Complaints, Projects, Staff, Reports  
**TechLayout** — minimal header with technician name and logout  

### Routing (wouter)

```
/                       → Public: Complaint registration
/track/:ticketId        → Public: Ticket status tracking
/admin                  → Staff login (redirect to dashboard/map based on role)
/admin/dashboard        → Admin: Dashboard with charts
/admin/complaints       → Admin: Complaints management table
/admin/projects         → Admin: Projects tracker
/admin/technicians      → Admin: Staff management
/admin/reports          → Admin: Report generation
/tech                   → Technician: Field map
```

---

## Admin Dashboard Design

### Stats Row (4 cards)
- Total Complaints
- Pending
- In Progress (assigned + going + reached)
- Completed

### Charts
- **Bar chart:** Complaints by district (Recharts BarChart)
- **Pie chart:** Complaints by urgency (Recharts PieChart)
- **Line chart:** Complaints over time (last 30 days)

### Recent Complaints Table
Latest 10 complaints with status badges, urgency indicators, technician name.

---

## Complaints Page Design

- Full-width data table with sortable columns
- Filter bar: Status dropdown, Urgency dropdown, Search (name/phone/ticket)
- Each row: Ticket ID, Customer, Location, Type, Urgency badge, Status badge, Technician, Date
- Click row → expand detail panel (right slide-in Sheet)
- Detail panel: Full complaint info + Assign technician + Set urgency + Status history

---

## Projects Page Design

### Left: Projects List
- Compact card grid/list
- Each card: FL No, Customer name, KW, Place, Quotation status badge, Closure status badge
- Search/filter controls
- "+ New Project" button

### Right: Project Detail Panel (Sheet)
Opens when a project is selected. Contains:

**Header:** Customer name, FL No, place, coordinator  

**Tab 1 — Project Info:** All basic fields (editable inline)  

**Tab 2 — Stages:** 12-stage checklist
- Each stage: checkbox (done/undone), stage name, last completed date, edit history popover
- "Stage Date" controls: "Save as Today" button OR calendar picker for custom date
- Save button (disabled until changes detected)

**Tab 3 — Quotation:** Upload PDF, approval status trail  

**Tab 4 — Activity Log:** Chronological list of all changes with timestamp and actor  

**Footer:** "Request Closure" button (only when CLIENT_APPROVED and not yet closed)

---

## Technician Map Design

**Full-screen interactive map** (react-leaflet, OpenStreetMap tiles)

### Pins
- Each assigned complaint → a map pin at complaint's GPS location
- Pin color = urgency: Red (critical), Orange (high), Amber (medium), Green (low)
- Click pin → popup with complaint details

### Popup Contents
- Customer name + address
- Complaint type + description
- Current status
- Action buttons based on status:
  - `assigned` → "Going" button
  - `going` → "Reached" button  
  - `reached` → "Complete" button (opens resolution notes dialog)

---

## Public Portal Design

### Complaint Form (Home page)
Clean single-column form on white background with brand-green accents.

**Sections:**
1. Customer Details (Name, Phone, Email, KSEB Consumer Number)
2. Location (GPS capture button → auto-fills place, district, pincode)
3. Complaint Type (dropdown)
4. Description (textarea)
5. Preferred Service Date (optional date picker)
6. Submit button

**GPS Capture:** Large green button. On click, browser requests geolocation. Coordinates are matched to nearest Kerala location in the 50-location dataset.

**After submission:** Displays ticket ID in a highlighted badge with copy button and "Track your complaint" link.

### Track Ticket Page
Single text input for ticket ID → displays current status with progress indicator.

---

## Email Design

Consistent branded email template with:

**Header section:** Dark green (`#1a5c38`) with company logo text, name, tagline, and email-specific title/subtitle. Icon emoji in large size.

**Body:** White background, Segoe UI font, max-width 620px.

**Ticket badge:** Green-bordered box with large monospace ticket ID.

**Progress bar:** Horizontal step indicator with green dots for completed steps.

**Detail table:** Alternating row colors (white/light gray), left column is label, right column is value.

**Alert boxes:** Colored left-border boxes for tips and warnings.

**Footer:** Contact email link, automated notice, copyright.

---

## Map Pin Colors (Leaflet)

Custom SVG pins with color based on urgency:

| Urgency | Pin Color |
|---|---|
| Critical | `#dc2626` (red) |
| High | `#ea580c` (orange) |
| Medium | `#d97706` (amber) |
| Low | `#16a34a` (green) |
| No urgency | `#6b7280` (gray) |
