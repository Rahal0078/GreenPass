# User Guide

---

## Part 1 — Customer (Public Portal)

### Submitting a Complaint

1. Open the website. You land on the **"Register a Complaint"** form.
2. Fill in **Customer Details**:
   - Full Name (required)
   - Phone Number (required)
   - Email Address (for status notifications)
   - KSEB Consumer Number (13-digit electricity account number)
3. **Location** (required): Tap the green **"Get My Location"** button.
   - Browser asks for location permission — click Allow.
   - Your GPS coordinates are captured and matched to the nearest Kerala town.
   - The place name, district, and pincode are auto-filled.
4. Select your **Complaint Type** from the dropdown (e.g. "Panel Not Generating", "Inverter Fault", "Wiring Issue").
5. Write a **Description** of the problem.
6. Optionally set a **Preferred Service Date**.
7. Click **"Submit Complaint"**.
8. A **Ticket ID** appears (format: `VKS-XXXXXXXXXX`). Copy and save it.
9. A confirmation email is sent to your email address.

### Tracking a Complaint

1. Click **"Track Ticket"** in the top navigation.
2. Enter your Ticket ID.
3. The current status is displayed: Pending → Assigned → Going → Reached → Completed.
4. You receive automatic emails at each status change.

---

## Part 2 — Admin Portal

### Logging In

1. Go to `/admin` (or click "Staff Login" on the public portal).
2. Enter username `admin` and password `admin123` (change in production).
3. Admin users are redirected to the **Dashboard**. Technicians go to the Field Map.

---

### Dashboard

The dashboard shows live statistics:

- **Top row:** Total complaints, Pending, In Progress, Completed (tap any card to filter the complaints list)
- **Charts:** Complaints by district (bar chart), by urgency (pie chart), daily trend (line chart)
- **Recent complaints:** Latest 10 with status and urgency

---

### Managing Complaints

Navigate to **Complaints** in the sidebar.

#### Viewing Complaints

- The table lists all complaints with: Ticket ID, Customer, Location, Type, Urgency, Status, Assigned Technician, Date.
- Filter by Status, Urgency, or search by name/phone/ticket ID.

#### Opening a Complaint

Click any row to open the detail panel on the right.

#### Setting Urgency

In the detail panel, use the **Urgency** dropdown:
- `Critical` — life/safety risk
- `High` — significant financial loss / system down
- `Medium` — partial fault
- `Low` — minor / cosmetic

#### Assigning a Technician

In the detail panel, select a technician from the **"Assign Technician"** dropdown, then click **Assign**.
- The customer receives an assignment notification email.
- The technician sees the complaint on their field map.

#### Multi-Technician Assignment

Multiple technicians can be added to the pending queue. Each sees the complaint on their map until one accepts it.

#### Deleting a Complaint

Click the **Delete** button in the detail panel (confirmation required).

---

### Managing Projects (Solar Installations)

Navigate to **Projects** in the sidebar.

#### Creating a Project

Click **"+ New Project"** and fill in:
- Customer Name, FL No (file reference), Place, KW (capacity)
- Phone, Email, KSEB Consumer No
- Total Amount (₹), Google Maps Link
- Coordinator (select from registered coordinators)
- Registered At (date)

#### Project Detail Panel

Click any project to open the detail panel. It has four tabs:

**Info Tab** — Edit any project field. Changes are saved inline.

**Stages Tab** — Track the 12 installation stages:

1. Check/uncheck stages to mark them done.
2. For each newly ticked stage, choose how to record the date:
   - Click **"Save as Today"** — saves today's date + current time.
   - Or click the calendar icon → pick a custom date → click **"Save"** — records the custom date AND the moment you saved it: `"01 Jun 2026 (recorded 06 Jun 26, 3:40 PM)"`.
3. Each stage shows its last completed date. Click the date to see full history.
4. Add per-stage remarks in the text boxes.

**Quotation Tab** — Manage the quotation approval chain:
1. Upload a PDF file → system sends approval email to coordinator.
2. Coordinator approves → system sends client approval email.
3. Client approves → quotation status becomes `CLIENT_APPROVED`.
4. If coordinator rejects → re-upload is required.

**Activity Log Tab** — Full change history with timestamps and who made each change.

#### Requesting Project Closure

When the project is complete (all stages done, quotation approved):
1. Click **"Request Closure"** in the panel footer.
2. An email is sent to the coordinator with approve/reject links.
3. On coordinator approval, closure status → `APPROVED`.

---

### Managing Staff (Technicians)

Navigate to **Technicians** in the sidebar.

#### Adding a Technician

Click **"+ Add Technician"** and fill in:
- Username and Password
- Full Name, Phone, Email
- Specialisation, Experience
- Role: `technician` or `coordinator`

#### Editing a Technician

Click on a technician card → edit details → save.

#### Deleting a Technician

Click the Delete button on a technician card (confirmation required).

---

### Reports

Navigate to **Reports** in the sidebar.

#### Downloading Excel Report

Click **"Download Excel Report"** to get a `.xlsx` file with all today's complaints including:
- Ticket ID, Customer Name, Phone, Location, Complaint Type
- Urgency, Status, Assigned Technician, Registration Date, Completion Date

#### Emailing Daily Report

Click **"Email Report"** to send the daily report to `info.vekay@gmail.com`.
Requires `GMAIL_APP_PASSWORD` environment variable to be set.

---

## Part 3 — Technician Portal

### Logging In

1. Go to `/admin` and enter your technician credentials.
2. You are redirected to the **Field Map**.

### Using the Field Map

The map shows all complaints assigned to you as colored pins:
- 🔴 Red = Critical
- 🟠 Orange = High
- 🟡 Amber = Medium
- 🟢 Green = Low

### Completing a Job

1. **Tap a pin** on the map to open the complaint popup.
2. Read the customer details and address.
3. Click **"Going"** when you leave for the job.
   - Customer receives "Technician On the Way" email.
4. Click **"Reached"** when you arrive.
   - Customer receives "Technician Arrived" email.
5. Complete the work.
6. Click **"Complete"** → enter resolution notes → confirm.
   - Customer receives "Complaint Resolved" email.
   - Pin disappears from your map.

### Push Notifications

When enabled (browser permission granted), you receive push notifications when:
- A new complaint is assigned to you.
- Admin sends a direct message.

---

## Part 4 — Coordinator Role

Coordinators receive emails with approval links. No portal login is required for basic workflows, but coordinators can log in to view projects.

### Quotation Approval (via email link)

1. You receive an email: "New Quotation for Review — [Customer Name]"
2. The email has a preview of the project details and a PDF download link.
3. Click **"Approve Quotation"** or **"Reject Quotation"**.
4. If approved, the client receives an approval link.
5. If rejected, admin is notified to re-upload.

### Project Closure Approval (via email link)

1. You receive an email: "Project Closure Request — [Customer Name]"
2. The email shows project summary.
3. Click **"Approve Closure"** or **"Reject Closure"**.
4. Your action is recorded in the project activity log.
