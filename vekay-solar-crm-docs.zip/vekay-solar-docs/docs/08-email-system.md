# Email System

**Transport:** Gmail SMTP via nodemailer  
**Sender:** `info.vekay@gmail.com` (configurable via `SENDER_EMAIL` env var)  
**Recipient default:** Customer email or `info.vekay@gmail.com` for admin reports  
**Branding:** GreenPass Technologies / VeKay Solar  
**Template:** Inline HTML with responsive design, max-width 620px

---

## Configuration

```env
GMAIL_APP_PASSWORD=xxxx-xxxx-xxxx-xxxx   # Required for all emails
SENDER_EMAIL=info.vekay@gmail.com         # Optional override
COMPANY_NAME=GreenPass Technologies       # Optional override
COMPANY_TAGLINE=Kerala's Leading Solar Project Expert  # Optional override
```

To generate a Gmail App Password:  
Google Account → Security → 2-Step Verification → App passwords → Create "Mail" app password.

If `GMAIL_APP_PASSWORD` is not set, all email calls are silently skipped with a warning log.

---

## Email Types

### 1. Complaint Registered

**Trigger:** Customer submits a complaint  
**To:** Customer email  
**Subject:** `Complaint Registered — VKS-XXXXXXXXXX | GreenPass Technologies`

**Contents:**
- Greeting with customer name
- Progress bar: ✅ Registered → Assigned → On the Way → Resolved
- Ticket ID badge (large monospace)
- Complaint details table: Type, Description, Location, Address, Pincode, Preferred Date, Registered On
- Yellow alert box: "Track your complaint anytime with your ticket ID"
- Contact footer

---

### 2. Technician Assigned

**Trigger:** Admin assigns a technician to a complaint  
**To:** Customer email  
**Subject:** `Technician Assigned — VKS-XXXXXXXXXX | GreenPass Technologies`

**Contents:**
- Progress bar: Registered ✅ → ✅ Assigned → On the Way → Resolved
- Technician profile card: Name, role, phone number (clickable tel: link)
- Complaint summary table
- Blue alert box: "The technician may call you before visiting"

---

### 3. Technician Going (On the Way)

**Trigger:** Technician clicks "Going" on field map  
**To:** Customer email  
**Subject:** `Technician Is On the Way — VKS-XXXXXXXXXX | GreenPass Technologies`

**Contents:**
- Progress bar: ✅✅ On the Way → Resolved
- Orange departure notice with technician name, departure time, phone
- Service location details
- Green alert box: "Please be at home"

---

### 4. Technician Reached (Arrived)

**Trigger:** Technician clicks "Reached" on field map  
**To:** Customer email  
**Subject:** `Technician Has Arrived — VKS-XXXXXXXXXX | GreenPass Technologies`

**Contents:**
- Progress bar: ✅✅✅ On-site → Resolved
- Green arrival notice with technician name, arrival time
- Service details table
- Blue alert box: "The technician will inspect and carry out repairs"

---

### 5. Complaint Completed

**Trigger:** Technician completes the job  
**To:** Customer email  
**Subject:** `Your Complaint Has Been Resolved — VKS-XXXXXXXXXX | GreenPass Technologies`

**Contents:**
- Progress bar: ✅✅✅✅✅ All complete
- Green "Service Completed" banner
- Technician's resolution notes (verbatim)
- Full service summary table
- Yellow alert box: "7-day free re-visit guarantee if issue persists"

---

### 6. Daily Report

**Trigger:** Admin clicks "Email Report" in Reports page, OR scheduled (if cron configured)  
**To:** `info.vekay@gmail.com`  
**Subject:** `Daily Complaint Report — [Date] | GreenPass Technologies`

**Contents:**
- Summary cards: Total, New Today, Resolved, Critical
- Full complaints table: Ticket ID, Customer, Phone, Location, Type, Urgency (colored badge), Status, Technician, Registered On
- Green brand header

---

### 7. Quotation Sent to Coordinator

**Trigger:** Admin uploads quotation PDF  
**To:** Coordinator's registered email address  
**Subject:** `New Quotation for Review — [Customer Name] | VeKay Solar`

**Contents:**
- Project summary (customer, place, kW, amount, coordinator)
- PDF download link (Google Drive)
- Approve button (token link): `GET /api/quotation/coordinator-approve/:token`
- Reject button (token link): `GET /api/quotation/coordinator-reject/:token`
- Tokens expire when used (one-time use)

---

### 8. Quotation Sent to Client

**Trigger:** Coordinator approves quotation  
**To:** Customer email (project.email field)  
**Subject:** `Your Solar Installation Quotation — [Customer Name] | VeKay Solar`

**Contents:**
- Project summary
- PDF download link
- Approve button: `GET /api/quotation/client-approve/:token`

---

### 9. Closure Request to Coordinator

**Trigger:** Admin clicks "Request Closure" on a project  
**To:** Coordinator's email  
**Subject:** `Project Closure Request — [Customer Name] | VeKay Solar`

**Contents:**
- Project summary (all fields)
- Stage completion status (which of 12 stages are done)
- Approve Closure button (token link)
- Reject Closure button (token link)

---

## Email Architecture

```typescript
// lib/email.ts

// All HTML is built as self-contained inline-styled HTML strings
// No external CSS — works in all email clients

// Shared helper functions:
// - header()       — green brand header block
// - ticketBadge()  — ticket ID display
// - detailTable()  — alternating-row data table
// - progressBar()  — horizontal step indicator
// - alertBox()     — colored alert/tip block
// - footer()       — contact + disclaimer

// Email send function:
async function sendEmail(to, subject, html, logMeta)
  // checks GMAIL_APP_PASSWORD
  // creates nodemailer transporter (Gmail SMTP, port 465, SSL)
  // sends with from: "GreenPass Technologies <info.vekay@gmail.com>"
  // logs success/failure with pino

// Exported functions:
export async function sendTicketRegistrationEmail(data: TicketEmailData)
export async function sendTechnicianAssignedEmail(data: AssignedEmailData)
export async function sendGoingEmail(data: StatusUpdateEmailData)
export async function sendReachedEmail(data: StatusUpdateEmailData)
export async function sendCompletedEmail(data: CompletedEmailData)
export async function sendDailyReportEmail(data: DailyReportEmailData)
export async function sendQuotationEmail(to, data)
export async function sendClientApprovalEmail(to, data)
export async function sendClosureRequestEmail(to, data)
```

---

## Coordinator Email Resolution

When sending coordinator emails, the server looks up the coordinator's email dynamically:

```typescript
async function resolveCoordinatorEmail(coordinatorName: string): Promise<string> {
  // Query technicians table: WHERE name = coordinatorName AND roles contains "coordinator"
  // If found: return technician.email
  // If not found or email blank: return "info.vekay@gmail.com" (fallback)
}
```

This means:
- The `projects.coordinator` field stores the **display name** as a string.
- The email is resolved at send time by name lookup.
- If the coordinator's name in the project doesn't match any technician, the email falls back to the company inbox.
