# Database Schema

**Database:** PostgreSQL (Neon cloud serverless)  
**ORM:** Drizzle ORM  
**Schema location:** `lib/db/src/schema/`

---

## Table: `admins`

Admin users who can access the admin portal.

| Column | Type | Constraints | Description |
|---|---|---|---|
| `id` | SERIAL | PRIMARY KEY | Auto-increment ID |
| `username` | TEXT | NOT NULL, UNIQUE | Login username |
| `password_hash` | TEXT | NOT NULL | bcrypt hash (10 rounds) |
| `name` | TEXT | NOT NULL | Display name |
| `email` | TEXT | NOT NULL | Admin email address |
| `created_at` | TIMESTAMPTZ | NOT NULL, DEFAULT NOW() | Creation timestamp |
| `updated_at` | TIMESTAMPTZ | NOT NULL, DEFAULT NOW() | Last update (auto) |

**Default record:** `admin` / `admin123`

---

## Table: `technicians`

Field technicians AND coordinators (role distinguished by `roles` JSON field).

| Column | Type | Constraints | Description |
|---|---|---|---|
| `id` | SERIAL | PRIMARY KEY | Auto-increment ID |
| `username` | TEXT | NOT NULL, UNIQUE | Login username |
| `password_hash` | TEXT | NOT NULL | bcrypt hash (10 rounds) |
| `name` | TEXT | NOT NULL | Display name |
| `phone` | TEXT | NOT NULL, DEFAULT '' | Contact number |
| `email` | TEXT | NOT NULL, DEFAULT '' | Contact email |
| `specialization` | TEXT | NOT NULL, DEFAULT '' | Technical specialisation |
| `experience` | TEXT | NOT NULL, DEFAULT '' | Years of experience |
| `roles` | TEXT | NOT NULL, DEFAULT '["technician"]' | JSON array of roles |
| `created_at` | TIMESTAMPTZ | NOT NULL, DEFAULT NOW() | Creation timestamp |
| `updated_at` | TIMESTAMPTZ | NOT NULL, DEFAULT NOW() | Last update (auto) |

### `roles` field values

The `roles` field is a JSON text array stored as a string.  
Possible values: `"technician"`, `"coordinator"`

Examples:
- Technician: `["technician"]`
- Coordinator: `["coordinator"]`
- Dual role: `["technician","coordinator"]`

**Parsing:** `JSON.parse(technician.roles)` or helper `parsePendingIds()`

**Default technicians:**

| Username | Name | Role | Password |
|---|---|---|---|
| `rajesh_k` | Rajesh Kumar | technician | `tech123` |
| `suresh_m` | Suresh Menon | technician | `tech456` |
| `anoop_v` | Anoop Varma | technician | `tech789` |
| `meera_coord` | Meera Nair | coordinator | `coord123` |

---

## Table: `complaints`

Customer service complaints for solar installations.

| Column | Type | Constraints | Description |
|---|---|---|---|
| `id` | SERIAL | PRIMARY KEY | Auto-increment ID |
| `ticket_id` | TEXT | NOT NULL, UNIQUE | Public ID e.g. `VKS-A1B2C3D4E5` |
| `customer_name` | TEXT | NOT NULL | Full name |
| `customer_phone` | TEXT | NOT NULL, DEFAULT '' | Phone number |
| `customer_email` | TEXT | NOT NULL, DEFAULT '' | Email for notifications |
| `consumer_no` | TEXT | NOT NULL, DEFAULT '' | 13-digit KSEB consumer number |
| `address` | TEXT | NOT NULL | Street/house address |
| `place_name` | TEXT | NOT NULL | Kerala town/village name |
| `district` | TEXT | NOT NULL, DEFAULT '' | Kerala district |
| `pincode` | TEXT | NOT NULL, DEFAULT '' | Postal code |
| `lat` | NUMERIC | nullable | GPS latitude (from browser) |
| `lng` | NUMERIC | nullable | GPS longitude (from browser) |
| `complaint_type` | TEXT | NOT NULL | Type of complaint |
| `description` | TEXT | NOT NULL, DEFAULT '' | Free-text description |
| `scheduled_date` | TEXT | nullable | Customer's preferred service date |
| `urgency` | TEXT | NOT NULL, DEFAULT 'medium' | `critical`/`high`/`medium`/`low` |
| `status` | TEXT | NOT NULL, DEFAULT 'pending' | See lifecycle below |
| `technician_id` | INTEGER | nullable, FK → technicians.id | Assigned technician |
| `pending_technician_ids` | TEXT | NOT NULL, DEFAULT '[]' | JSON array of tech IDs (multi-assign queue) |
| `resolution_notes` | TEXT | NOT NULL, DEFAULT '' | Technician's completion notes |
| `created_at` | TIMESTAMPTZ | NOT NULL, DEFAULT NOW() | Submission time |
| `updated_at` | TIMESTAMPTZ | NOT NULL, DEFAULT NOW() | Last change |

### `status` lifecycle

```
pending → assigned → going → reached → completed
```

| Status | Meaning |
|---|---|
| `pending` | Submitted, no technician assigned yet |
| `assigned` | Technician assigned by admin |
| `going` | Technician has marked themselves as on the way |
| `reached` | Technician has arrived at customer location |
| `completed` | Technician has resolved and submitted notes |

### `urgency` colours

| Urgency | Color |
|---|---|
| `critical` | Red |
| `high` | Orange |
| `medium` | Amber |
| `low` | Green |

### `ticket_id` format

Generated as `VKS-` + 10 uppercase alphanumeric characters.  
Example: `VKS-A1B2C3D4E5`

---

## Table: `projects`

Solar installation projects (separate from complaint tickets).

| Column | Type | Constraints | Description |
|---|---|---|---|
| `id` | SERIAL | PRIMARY KEY | Auto-increment ID |
| `registered_at` | TEXT | NOT NULL, DEFAULT '' | Registration date (IST string) |
| `fl_no` | TEXT | NOT NULL, DEFAULT '' | File/project reference number (e.g. `FL-001`) |
| `customer_name` | TEXT | NOT NULL | Customer full name |
| `place` | TEXT | NOT NULL, DEFAULT '' | Installation location |
| `kw` | TEXT | NOT NULL, DEFAULT '' | System capacity in kilowatts |
| `phone` | TEXT | NOT NULL, DEFAULT '' | Customer phone |
| `email` | TEXT | NOT NULL, DEFAULT '' | Customer email |
| `consumer_no` | TEXT | NOT NULL, DEFAULT '' | KSEB consumer number |
| `total_amount` | TEXT | NOT NULL, DEFAULT '' | Project total in INR |
| `gmap_link` | TEXT | NOT NULL, DEFAULT '' | Google Maps link to site |
| `coordinator` | TEXT | NOT NULL, DEFAULT '' | Coordinator name (matched to technicians) |
| `quotation` | TEXT | NOT NULL, DEFAULT 'PENDING' | Quotation workflow status |
| `quotation_file_id` | TEXT | DEFAULT '' | Google Drive file ID of PDF |
| `quotation_token` | TEXT | DEFAULT '' | Coordinator approval token (UUID) |
| `quotation_client_token` | TEXT | DEFAULT '' | Client approval token (UUID) |
| `stages` | TEXT | NOT NULL, DEFAULT '[]' | JSON: 12-element string array of stage values |
| `stage_remarks` | TEXT | NOT NULL, DEFAULT '[]' | JSON: 12-element string array of remarks |
| `stage_log` | TEXT | NOT NULL, DEFAULT '[]' | JSON: 12-element array of string[] (timestamps per edit) |
| `remark` | TEXT | NOT NULL, DEFAULT '' | Free-text overall remark |
| `activity_log` | TEXT | NOT NULL, DEFAULT '[]' | JSON: [{ts, actor, text}] change log |
| `closure_status` | TEXT | NOT NULL, DEFAULT 'PENDING' | Closure workflow status |
| `closure_token` | TEXT | DEFAULT '' | Coordinator closure approval token |
| `created_at` | TIMESTAMPTZ | NOT NULL, DEFAULT NOW() | Record creation time |
| `updated_at` | TIMESTAMPTZ | NOT NULL, DEFAULT NOW() | Last update time |

### Quotation workflow states

```
PENDING → SENT → COORDINATOR_APPROVED → CLIENT_APPROVED
                ↘ COORDINATOR_REJECTED  (re-upload required)
```

| State | Meaning |
|---|---|
| `PENDING` | No quotation uploaded yet |
| `SENT` | PDF uploaded, coordinator approval email sent |
| `COORDINATOR_APPROVED` | Coordinator approved, client approval email sent |
| `COORDINATOR_REJECTED` | Coordinator rejected, re-upload required |
| `CLIENT_APPROVED` | Client approved, project proceeds |

### Closure workflow states

```
PENDING → REQUESTED → APPROVED
                    ↘ REJECTED (can re-request)
```

### The 12 Project Stages

| Index | Stage Name |
|---|---|
| 0 | Application Submitted |
| 1 | Survey Completed |
| 2 | Sanction Approved |
| 3 | Material Purchased |
| 4 | Installation Started |
| 5 | Installation Completed |
| 6 | Inspection Done |
| 7 | Net Meter Applied |
| 8 | Net Meter Installed |
| 9 | Subsidy Applied |
| 10 | Subsidy Received |
| 11 | Project Closed |

### Stage Log Format

The `stage_log` column is a JSON string containing a 12-element array. Each element is an array of timestamp strings representing when that stage was toggled.

When admin saves with **"Save as Today"**: timestamp = `"06 Jun 26, 3:40 PM"` (IST)  
When admin saves with **custom date**: timestamp = `"01 Jun 2026 (recorded 06 Jun 26, 3:40 PM)"`

```json
[
  ["06 Jun 26, 3:40 PM"],           // stage 0: toggled once
  ["01 Jun 26, 12:00 PM", "02 Jun 2026 (recorded 06 Jun 26, 4:00 PM)"], // stage 1: toggled twice
  [],                                // stage 2: never toggled
  ...
]
```

### Activity Log Format

```json
[
  {
    "ts": "06 Jun 26, 3:40 PM",
    "actor": "admin",
    "text": "Stage 'Installation Started' marked complete"
  },
  {
    "ts": "06 Jun 26, 2:00 PM",
    "actor": "admin",
    "text": "Project created"
  }
]
```

---

## Table: `session`

Auto-managed by `connect-pg-simple`. Stores Express sessions.

| Column | Type | Description |
|---|---|---|
| `sid` | TEXT (PK) | Session ID (cookie value) |
| `sess` | JSONB | Session data (userId, role, name, etc.) |
| `expire` | TIMESTAMPTZ | Session expiry timestamp |

---

## Relationships

```
technicians.id ←── complaints.technician_id  (assigned technician)
technicians.name ←── projects.coordinator    (matched by name string, not FK)
admins ←── session.sess.userId               (admin sessions)
technicians ←── session.sess.userId          (technician/coordinator sessions)
```

Note: `projects.coordinator` stores the coordinator's display **name** as a string (not a foreign key). The server resolves the coordinator's email by querying `technicians` by name at email-send time.
