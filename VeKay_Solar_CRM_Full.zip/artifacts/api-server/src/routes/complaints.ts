import { Router } from "express";
import type { IRouter } from "express";
import rateLimit from "express-rate-limit";
import { db, complaintsTable, techniciansTable } from "@workspace/db";
import { eq, desc, and, sql } from "drizzle-orm";
import {
  CreateComplaintBody,
  UpdateComplaintBody,
  UpdateComplaintParams,
  GetComplaintParams,
  CompleteComplaintBody,
  CompleteComplaintParams,
  GetComplaintByTicketParams,
} from "@workspace/api-zod";
import { generateTicketId } from "../lib/auth";
import {
  sendTicketConfirmationEmail,
  sendTechnicianAssignedEmail,
  sendTechnicianGoingEmail,
  sendTechnicianReachedEmail,
  sendJobCompletedEmail,
} from "../lib/email";
import { syncToSheets } from "../lib/sheets";
import { sendPushToTechnicians } from "./push";

const router: IRouter = Router();

// 5 complaint submissions per IP per 15 minutes (public form only)
const submitLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many complaints submitted from this device. Please try again in 15 minutes." },
});

function urgencyToColor(urgency: string): string {
  switch (urgency) {
    case "critical": return "#7f1d1d";
    case "high": return "#dc2626";
    case "medium": return "#f97316";
    case "low": return "#3b82f6";
    default: return "#6b7280";
  }
}

function parsePendingIds(raw: string | null | undefined): number[] {
  if (!raw) return [];
  try { return JSON.parse(raw) as number[]; } catch { return []; }
}

async function enrichComplaint(complaint: typeof complaintsTable.$inferSelect) {
  let technicianName: string | null = null;
  if (complaint.technicianId) {
    const [tech] = await db.select({ name: techniciansTable.name })
      .from(techniciansTable)
      .where(eq(techniciansTable.id, complaint.technicianId));
    technicianName = tech?.name ?? null;
  }
  return {
    ...complaint,
    technicianName,
    pendingTechnicianIds: parsePendingIds(complaint.pendingTechnicianIds),
    scheduledDate: complaint.scheduledDate ?? null,
    completedAt: complaint.completedAt ? complaint.completedAt.toISOString() : null,
    createdAt: complaint.createdAt.toISOString(),
    updatedAt: complaint.updatedAt.toISOString(),
  };
}

router.get("/complaints", async (req, res): Promise<void> => {
  const session = req.session as any;
  if (!session?.userId || session.role !== "admin") {
    res.status(401).json({ error: "Admin authentication required" });
    return;
  }

  const { status, urgency, technicianId } = req.query;

  let conditions = [];
  if (status && typeof status === "string") {
    conditions.push(eq(complaintsTable.status, status));
  }
  if (urgency && typeof urgency === "string") {
    conditions.push(eq(complaintsTable.urgency, urgency));
  }
  if (technicianId && typeof technicianId === "string") {
    const techId = parseInt(technicianId, 10);
    if (!isNaN(techId)) {
      conditions.push(eq(complaintsTable.technicianId, techId));
    }
  }

  const complaints = conditions.length > 0
    ? await db.select().from(complaintsTable).where(and(...conditions)).orderBy(desc(complaintsTable.createdAt))
    : await db.select().from(complaintsTable).orderBy(desc(complaintsTable.createdAt));

  const enriched = await Promise.all(complaints.map(enrichComplaint));
  res.json(enriched);
});

router.post("/complaints", submitLimiter, async (req, res): Promise<void> => {
  const parsed = CreateComplaintBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const ticketId = generateTicketId();
  const urgencyColor = urgencyToColor("low");

  let complaint: typeof complaintsTable.$inferSelect;
  try {
    const [inserted] = await db.insert(complaintsTable).values({
      ...parsed.data,
      ticketId,
      status: "open",
      urgency: "low",
      urgencyColor,
      scheduledDate: parsed.data.scheduledDate ?? null,
    }).returning();
    complaint = inserted;
  } catch (err: unknown) {
    const cause = (err as { cause?: unknown }).cause;
    req.log.error({ err, cause, causeMsg: cause instanceof Error ? cause.message : String(cause) }, "Complaint insert failed");
    res.status(500).json({ error: "Failed to create complaint" });
    return;
  }

  const enriched = await enrichComplaint(complaint);
  res.status(201).json(enriched);

  sendTicketConfirmationEmail({
    customerName: complaint.customerName,
    customerEmail: complaint.customerEmail,
    ticketId: complaint.ticketId,
    complaintType: complaint.complaintType,
    description: complaint.description,
    placeName: complaint.placeName,
    district: complaint.district,
    pincode: complaint.pincode,
    address: complaint.address,
    createdAt: complaint.createdAt.toISOString(),
    scheduledDate: complaint.scheduledDate ?? null,
  }).catch(() => {});
  syncToSheets().catch(() => {});
});

router.get("/complaints/lookup", async (req, res): Promise<void> => {
  const q = typeof req.query.q === "string" ? req.query.q.trim() : "";
  if (!q || q.length < 5) {
    res.status(400).json({ error: "Search query too short" });
    return;
  }

  const { or, ilike, like } = await import("drizzle-orm");
  const results = await db.select().from(complaintsTable)
    .where(
      or(
        ilike(complaintsTable.customerEmail, `%${q}%`),
        like(complaintsTable.customerPhone, `%${q}%`)
      )
    )
    .orderBy(desc(complaintsTable.createdAt))
    .limit(20);

  const enriched = await Promise.all(results.map(enrichComplaint));
  res.json(enriched);
});

router.get("/complaints/ticket/:ticketId", async (req, res): Promise<void> => {
  const params = GetComplaintByTicketParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [complaint] = await db.select().from(complaintsTable)
    .where(eq(complaintsTable.ticketId, params.data.ticketId));

  if (!complaint) {
    res.status(404).json({ error: "Ticket not found" });
    return;
  }

  const enriched = await enrichComplaint(complaint);
  res.json(enriched);
});

router.get("/complaints/:id", async (req, res): Promise<void> => {
  const params = GetComplaintParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [complaint] = await db.select().from(complaintsTable)
    .where(eq(complaintsTable.id, params.data.id));

  if (!complaint) {
    res.status(404).json({ error: "Complaint not found" });
    return;
  }

  const enriched = await enrichComplaint(complaint);
  res.json(enriched);
});

router.delete("/complaints/:id", async (req, res): Promise<void> => {
  const params = GetComplaintParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [deleted] = await db.delete(complaintsTable)
    .where(eq(complaintsTable.id, params.data.id))
    .returning({ id: complaintsTable.id });

  if (!deleted) {
    res.status(404).json({ error: "Complaint not found" });
    return;
  }

  res.status(204).end();
  syncToSheets().catch(() => {});
});

router.patch("/complaints/:id", async (req, res): Promise<void> => {
  const params = UpdateComplaintParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateComplaintBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  if ((parsed.data as any).status === "resolved") {
    res.status(400).json({ error: "Use POST /complaints/:id/complete to mark a job as resolved" });
    return;
  }

  const [before] = await db.select().from(complaintsTable).where(eq(complaintsTable.id, params.data.id));
  if (!before) {
    res.status(404).json({ error: "Complaint not found" });
    return;
  }

  // Exclude fields we handle manually (pendingTechnicianIds needs JSON serialisation)
  const { pendingTechnicianIds: _ignored, ...restParsed } = parsed.data as any;
  const updates: Partial<typeof complaintsTable.$inferInsert> = { ...restParsed };

  if (updates.urgency && !updates.urgencyColor) {
    updates.urgencyColor = urgencyToColor(updates.urgency);
  }

  // Handle pendingTechnicianIds from raw body (array or null)
  const rawPendingIds = (req.body as any).pendingTechnicianIds;
  if (rawPendingIds === null || rawPendingIds === undefined) {
    // not provided — leave unchanged unless explicitly null
    if (Object.prototype.hasOwnProperty.call(req.body, "pendingTechnicianIds")) {
      updates.pendingTechnicianIds = null;
    }
  } else if (Array.isArray(rawPendingIds)) {
    updates.pendingTechnicianIds = rawPendingIds.length > 0 ? JSON.stringify(rawPendingIds) : null;
  }

  if (updates.scheduledDate !== undefined) {
    updates.scheduledDate = updates.scheduledDate ?? null;
  }

  const [complaint] = await db.update(complaintsTable)
    .set(updates)
    .where(eq(complaintsTable.id, params.data.id))
    .returning();

  if (!complaint) {
    res.status(404).json({ error: "Complaint not found" });
    return;
  }

  const enriched = await enrichComplaint(complaint);
  res.json(enriched);

  syncToSheets().catch(() => {});

  const now = new Date().toISOString();

  async function getTech(techId: number) {
    const [t] = await db.select({ name: techniciansTable.name, phone: techniciansTable.phone })
      .from(techniciansTable).where(eq(techniciansTable.id, techId));
    return t ?? { name: "VeKay Solar Technician", phone: "" };
  }

  const baseData = {
    customerName: complaint.customerName,
    customerEmail: complaint.customerEmail,
    ticketId: complaint.ticketId,
    complaintType: complaint.complaintType,
    description: complaint.description,
    placeName: complaint.placeName,
    district: complaint.district,
    pincode: complaint.pincode,
    address: complaint.address,
    createdAt: complaint.createdAt.toISOString(),
    urgency: complaint.urgency,
    scheduledDate: complaint.scheduledDate ?? null,
  };

  // Direct technician assignment changed
  if (complaint.technicianId && complaint.technicianId !== before.technicianId) {
    getTech(complaint.technicianId).then((tech) => {
      sendTechnicianAssignedEmail({ ...baseData, technicianName: tech.name, technicianPhone: tech.phone ?? "" });
      sendPushToTechnicians([complaint.technicianId!], {
        title: "New Job Assigned",
        body: `Complaint ${complaint.ticketId} in ${complaint.placeName} has been assigned to you.`,
        data: { url: `/tech/complaints/${complaint.id}` },
      });
    }).catch(() => {});
  }

  // Pending technicians set (first-to-accept)
  const newPendingIds = parsePendingIds(complaint.pendingTechnicianIds);
  const oldPendingIds = parsePendingIds(before.pendingTechnicianIds);
  const addedPendingIds = newPendingIds.filter(id => !oldPendingIds.includes(id));
  if (addedPendingIds.length > 0) {
    sendPushToTechnicians(addedPendingIds, {
      title: "New Job Available",
      body: `Complaint ${complaint.ticketId} in ${complaint.placeName} — first to accept gets assigned!`,
      data: { url: `/tech/complaints/${complaint.id}` },
    }).catch(() => {});
  }

  if (complaint.status === "going" && before.status !== "going") {
    const techId = complaint.technicianId;
    (techId ? getTech(techId) : Promise.resolve({ name: "VeKay Solar Technician", phone: "" })).then((tech) =>
      sendTechnicianGoingEmail({ ...baseData, technicianName: tech.name, technicianPhone: tech.phone ?? "", statusAt: now })
    ).catch(() => {});
  }

  if (complaint.status === "reached" && before.status !== "reached") {
    const techId = complaint.technicianId;
    (techId ? getTech(techId) : Promise.resolve({ name: "VeKay Solar Technician", phone: "" })).then((tech) =>
      sendTechnicianReachedEmail({ ...baseData, technicianName: tech.name, technicianPhone: tech.phone ?? "", statusAt: now })
    ).catch(() => {});
  }
});

// Technician accepts a pending assignment (first-to-accept)
router.post("/complaints/:id/accept", async (req, res): Promise<void> => {
  const params = GetComplaintParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const session = req.session as any;
  if (!session?.userId || session.role !== "technician") {
    res.status(401).json({ error: "Not authenticated as technician" });
    return;
  }

  const techId: number = session.userId;

  const [before] = await db.select().from(complaintsTable).where(eq(complaintsTable.id, params.data.id));
  if (!before) {
    res.status(404).json({ error: "Complaint not found" });
    return;
  }

  const pendingIds = parsePendingIds(before.pendingTechnicianIds);
  if (!pendingIds.includes(techId) && before.technicianId !== techId) {
    res.status(403).json({ error: "You are not in the pending list for this complaint" });
    return;
  }

  if (before.technicianId && before.technicianId !== techId) {
    res.status(409).json({ error: "This complaint was already accepted by another technician" });
    return;
  }

  const [complaint] = await db.update(complaintsTable)
    .set({
      technicianId: techId,
      pendingTechnicianIds: null,
      status: before.status === "open" ? "in_progress" : before.status,
    })
    .where(eq(complaintsTable.id, params.data.id))
    .returning();

  if (!complaint) {
    res.status(404).json({ error: "Complaint not found" });
    return;
  }

  const enriched = await enrichComplaint(complaint);
  res.json(enriched);

  syncToSheets().catch(() => {});

  // Send assigned email to customer
  const [tech] = await db.select({ name: techniciansTable.name, phone: techniciansTable.phone })
    .from(techniciansTable).where(eq(techniciansTable.id, techId));
  if (tech) {
    sendTechnicianAssignedEmail({
      customerName: complaint.customerName,
      customerEmail: complaint.customerEmail,
      ticketId: complaint.ticketId,
      complaintType: complaint.complaintType,
      description: complaint.description,
      placeName: complaint.placeName,
      district: complaint.district,
      pincode: complaint.pincode,
      address: complaint.address,
      createdAt: complaint.createdAt.toISOString(),
      urgency: complaint.urgency,
      scheduledDate: complaint.scheduledDate ?? null,
      technicianName: tech.name,
      technicianPhone: tech.phone ?? "",
    }).catch(() => {});
  }
});

router.post("/complaints/:id/complete", async (req, res): Promise<void> => {
  const params = CompleteComplaintParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = CompleteComplaintBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const session = req.session as any;
  if (!session?.userId || !["technician", "admin"].includes(session.role)) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }

  const [before] = await db.select().from(complaintsTable).where(eq(complaintsTable.id, params.data.id));
  if (!before) {
    res.status(404).json({ error: "Complaint not found" });
    return;
  }

  if (before.status === "resolved" || before.status === "closed") {
    res.status(409).json({ error: "This complaint is already resolved" });
    return;
  }

  if (before.status === "open") {
    res.status(400).json({ error: "Cannot complete a job that has not been started yet" });
    return;
  }

  const completedAt = new Date();

  const [complaint] = await db.update(complaintsTable)
    .set({
      status: "resolved",
      completionNotes: parsed.data.completionNotes,
      completedAt,
    })
    .where(eq(complaintsTable.id, params.data.id))
    .returning();

  if (!complaint) {
    res.status(404).json({ error: "Complaint not found" });
    return;
  }

  const enriched = await enrichComplaint(complaint);
  res.json(enriched);

  const getTechName = async () => {
    if (!complaint.technicianId) return "VeKay Solar Technician";
    const [t] = await db.select({ name: techniciansTable.name }).from(techniciansTable)
      .where(eq(techniciansTable.id, complaint.technicianId));
    return t?.name ?? "VeKay Solar Technician";
  };

  getTechName().then((techName) =>
    sendJobCompletedEmail({
      customerName: complaint.customerName,
      customerEmail: complaint.customerEmail,
      ticketId: complaint.ticketId,
      complaintType: complaint.complaintType,
      description: complaint.description,
      placeName: complaint.placeName,
      district: complaint.district,
      pincode: complaint.pincode,
      address: complaint.address,
      createdAt: complaint.createdAt.toISOString(),
      urgency: complaint.urgency,
      scheduledDate: complaint.scheduledDate ?? null,
      technicianName: techName,
      completedAt: completedAt.toISOString(),
      completionNotes: parsed.data.completionNotes,
    })
  ).catch(() => {});
  syncToSheets().catch(() => {});
});

export default router;
